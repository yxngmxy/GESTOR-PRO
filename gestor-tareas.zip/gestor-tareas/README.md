# Gestor de tareas y proyectos

Aplicación en Java para organizar el trabajo personal o de un equipo. Tiene **un único núcleo** (`com.gestor.core`)
y **dos interfaces** que lo usan: consola (`com.gestor.cli`) y gráfica Swing (`com.gestor.gui`).
Ninguna de las dos contiene reglas de negocio: todo pasa por la fachada `TaskManager`.

## Requisitos
- JDK 17 o superior (probado con JDK 21).
- Maven 3.8+ (opcional; también se puede compilar solo con `javac`).

## Compilar y ejecutar

### Con Maven
```bash
mvn test                      # compila y ejecuta las pruebas unitarias
mvn package                   # genera target/gestor-tareas-1.0.0.jar

java -jar target/gestor-tareas-1.0.0.jar [--demo]                              # consola
java -cp target/gestor-tareas-1.0.0.jar com.gestor.gui.GuiApp [--demo]         # interfaz gráfica
```

### Sin Maven
```bash
./build.sh                                  # compila a ./out
java -cp out com.gestor.cli.ConsoleMain --demo
java -cp out com.gestor.gui.GuiApp --demo
./build.sh test /ruta/junit-platform-console-standalone-1.10.x.jar   # compila y corre las pruebas
```
`--demo` carga un proyecto de ejemplo con tareas, responsables y una fecha vencida.

## Funcionalidades implementadas
| Requisito | Dónde / cómo se usa |
|---|---|
| Tareas simples y compuestas (subtareas anidadas) | `nueva <título> [grupo] [en=ID]`; en la GUI, *Nueva tarea / compuesta / subtarea*. El progreso de un grupo es el promedio de sus subtareas. |
| Estados con transiciones controladas | Pendiente → En curso → En revisión → Terminada (con retrocesos permitidos y reapertura). Un grupo no puede terminar si tiene subtareas sin terminar. La GUI solo ofrece los estados permitidos. |
| Deshacer / rehacer | `deshacer`, `rehacer`; botones y Ctrl+Z / Ctrl+Y. Cubre crear/eliminar tareas y proyectos, estados, prioridad, fecha, responsables, título y descripción. |
| Recordatorios y alertas | `alertas` revisa las fechas límite (próximas a vencer en 24 h y vencidas); avisa **a todos los responsables** de la tarea. En la GUI se revisa solo cada 30 s. Bandeja por usuario: `bandeja [usuario]`. |
| Plantillas | Guardar una tarea (con sus subtareas) o un proyecto completo como plantilla y crear copias nuevas; opcionalmente desplaza todas las fechas. |
| Ordenar y filtrar | Orden por prioridad, fecha o responsable (y invertir). Filtros por estado, prioridad mínima, responsable, texto y vencidas. Los grupos se conservan si alguna subtarea coincide. |

## Comandos de la consola
```
proyecto <nombre> | proyectos | usar <id|nombre>
nueva <título> [grupo] [en=ID] [prioridad=ALTA] [fecha=2026-12-31] [resp=ana,luis]
listar [orden=prioridad|fecha|responsable] [desc] [estado=..] [resp=..] [prioridad=..] [vencidas] [texto=..] [plano]
ver <id> | estado <id> <estado> | prioridad <id> <p> | fecha <id> <f|ninguna>
resp <id> <a,b> | renombrar <id> <título> | eliminar <id>
deshacer | rehacer | alertas | bandeja [usuario]
plantilla guardar <nombre> <idTarea> | plantilla guardar-proyecto <nombre>
plantilla usar <nombre> [en=ID] [fecha=..] | plantilla usar-proyecto <plantilla> <nuevo> [fecha=..] | plantillas
ayuda | salir
```
Los títulos con espacios pueden ir entre comillas. Fechas: `aaaa-mm-dd` (se toma 23:59) o `aaaa-mm-dd hh:mm`.

## Estructura de paquetes
```
com.gestor.core.model     Task (Composite), SimpleTask, CompositeTask, Project, Priority
com.gestor.core.state     TaskState (State) y sus estados concretos, TaskStatus, StateContext
com.gestor.core.command   Command, CommandHistory y comandos concretos (deshacer/rehacer)
com.gestor.core.notify    EventPublisher, TaskListener (Observer), DeadlineChecker, UserInbox, ConsoleNotifier
com.gestor.core.template  TemplateRegistry (Prototype)
com.gestor.core.query     SortStrategy (Strategy) y sus implementaciones, Filters, TaskQuery
com.gestor.core.service   TaskManager (fachada), DemoData
com.gestor.core.util      IdGenerator, Dates, Texts
com.gestor.cli            ConsoleApp, ConsoleMain
com.gestor.gui            GuiApp, TaskTreeRenderer
```
Dependencias: `cli` y `gui` → `core.service`; el núcleo no conoce las interfaces. `core.state` no depende de `core.model`
(usa la interfaz `StateContext`).

## Patrones aplicados (resumen)
| Patrón | Problema | Clases principales |
|---|---|---|
| Composite | Tratar igual una tarea y un grupo de subtareas | `Task`, `SimpleTask`, `CompositeTask` |
| State | Transiciones permitidas sin `if/switch` | `TaskState`, `PendingState`, `InProgressState`, `InReviewState`, `DoneState` |
| Command | Deshacer y rehacer cualquier acción | `Command`, `CommandHistory`, `AddTaskCommand`, `ChangeStatusCommand`, ... |
| Observer | Avisar a varios responsables por varios canales | `EventPublisher`, `TaskListener`, `UserInbox`, `ConsoleNotifier`, `DeadlineChecker` |
| Prototype | Crear tareas/proyectos recurrentes desde un modelo | `Task.deepCopy`, `Project.deepCopy`, `TemplateRegistry` |
| Strategy | Ordenar con criterios intercambiables | `SortStrategy`, `PrioritySort`, `DueDateSort`, `AssigneeSort`, `NoSort` |
| Facade (apoyo) | Un único punto de entrada para ambas interfaces | `TaskManager` |

## Pruebas unitarias
En `src/test/java/com/gestor`, una clase por patrón: `StatePatternTest`, `CompositePatternTest`, `CommandPatternTest`,
`ObserverPatternTest`, `PrototypePatternTest`, `StrategyPatternTest`, más `TaskManagerTest` (integración de la fachada)
y `ConsoleAppTest`. El reloj se inyecta (`TestClock`), así que las alertas se prueban sin esperas reales.

## Equipo y repositorio
Cada integrante debe hacer sus propios commits (un paquete o patrón por persona, con ramas y *pull requests*).
Sugerencia de reparto: model+state / command+service / notify+template / query+tests / cli / gui+documento.
