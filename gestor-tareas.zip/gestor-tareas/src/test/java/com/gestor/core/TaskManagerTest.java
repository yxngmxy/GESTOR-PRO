package com.gestor.core;

import com.gestor.core.model.*;
import com.gestor.core.service.TaskManager;
import com.gestor.core.state.InvalidTransitionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

import static com.gestor.core.state.TaskStatus.*;
import static org.junit.jupiter.api.Assertions.*;

/** Pruebas de integración de la fachada: los patrones trabajando juntos. */
class TaskManagerTest {
    TestClock clock;
    TaskManager tm;
    Project p;

    @BeforeEach
    void setUp() {
        clock = new TestClock(LocalDateTime.of(2026, 11, 20, 9, 0));
        tm = new TaskManager(clock);
        p = tm.createProject("Demo");
    }

    @Test
    void taskIdsStartAtOneAndAreIndependentOfProjectIds() {
        Task t = tm.addTask(p, null, "primera", false);
        assertEquals(1, t.id());
        assertEquals(1, p.id());
    }

    @Test
    void subtasksOnlyInCompositeTasks() {
        Task simple = tm.addTask(p, null, "simple", false);
        assertThrows(IllegalArgumentException.class, () -> tm.addTask(p, simple, "hija", false));
        Task group = tm.addTask(p, null, "grupo", true);
        Task child = tm.addTask(p, group, "hija", false);
        assertSame(group, child.parent());
        assertEquals(group.id(), tm.findTask(child.id()).orElseThrow().parent().id());
    }

    @Test
    void everyUserActionCanBeUndoneAndRedone() {
        Task t = tm.addTask(p, null, "t", false);
        tm.setPriority(t, Priority.URGENT);
        tm.assign(t, List.of("ana"));
        tm.changeStatus(t, IN_PROGRESS);
        tm.rename(t, "nuevo");

        tm.undo(); tm.undo(); tm.undo(); tm.undo();
        assertEquals("t", t.title());
        assertEquals(PENDING, t.status());
        assertTrue(t.assignees().isEmpty());
        assertEquals(Priority.MEDIUM, t.priority());

        tm.redo(); tm.redo(); tm.redo(); tm.redo();
        assertEquals("nuevo", t.title());
        assertEquals(IN_PROGRESS, t.status());
        assertEquals(Priority.URGENT, t.priority());
    }

    @Test
    void invalidTransitionDoesNotPolluteHistory() {
        Task t = tm.addTask(p, null, "t", false);
        int before = tm.history().undoSize();
        assertThrows(InvalidTransitionException.class, () -> tm.changeStatus(t, DONE));
        assertEquals(before, tm.history().undoSize());
    }

    @Test
    void assigningNotifiesOnlyNewResponsibles() {
        Task t = tm.addTask(p, null, "t", false);
        tm.assign(t, List.of("ana"));
        tm.assign(t, List.of("ana", "luis"));
        assertEquals(1, tm.inbox().messagesFor("ana").stream().filter(m -> m.contains("asignó")).count());
        assertEquals(1, tm.inbox().messagesFor("luis").size());
    }

    @Test
    void deadlineAlertsGoToEveryResponsible() {
        Task t = tm.addTask(p, null, "entrega", false);
        tm.assign(t, List.of("ana", "luis"));
        tm.setDueDate(t, clock.nowLocal().plusHours(3));
        tm.inbox().clear();
        assertEquals(1, tm.checkDeadlines().size());
        assertEquals(1, tm.inbox().messagesFor("ana").size());
        assertEquals(1, tm.inbox().messagesFor("luis").size());
        clock.advance(Duration.ofHours(4));
        assertEquals(1, tm.checkDeadlines().size()); // ahora OVERDUE
    }

    @Test
    void projectFromTemplateIsIndependentAndUndoable() {
        Task g = tm.addTask(p, null, "grupo", true);
        tm.addTask(p, g, "hija", false);
        tm.templates().saveProject("base", p);

        Project copy = tm.createProjectFromTemplate("base", "Copia", null);
        assertEquals(2, tm.projects().size());
        assertEquals(2, copy.allTasks().size());
        tm.addTask(copy, null, "extra", false);
        assertEquals(2, p.allTasks().size(), "el proyecto original no cambia");

        tm.undo(); // quita "extra"
        tm.undo(); // quita el proyecto copia
        assertEquals(1, tm.projects().size());
    }

    @Test
    void taskFromTemplateIsInsertedWhereRequested() {
        Task g = tm.addTask(p, null, "grupo", true);
        Task leaf = tm.addTask(p, g, "hija", false);
        tm.templates().saveTask("plan", g);
        Task other = tm.addTask(p, null, "otro grupo", true);
        Task copy = tm.addTaskFromTemplate(p, other, "plan", null);
        assertSame(other, copy.parent());
        assertEquals(1, copy.children().size());
        assertNotEquals(leaf.id(), copy.children().get(0).id());
    }

    @Test
    void findersWork() {
        Task t = tm.addTask(p, null, "t", false);
        assertEquals(p, tm.findProject("demo").orElseThrow());
        assertEquals(p, tm.findProject("1").orElseThrow());
        assertEquals(p, tm.projectOf(t).orElseThrow());
        assertTrue(tm.findTask(999).isEmpty());
    }
}
