package com.gestor.core;

import java.time.Clock;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;

/** Reloj controlable para pruebas: permite "avanzar el tiempo" sin esperar. */
public class TestClock extends Clock {
    private Instant now;

    public TestClock(LocalDateTime start) { this.now = start.toInstant(ZoneOffset.UTC); }

    public void advance(Duration d) { now = now.plus(d); }

    public LocalDateTime nowLocal() { return LocalDateTime.ofInstant(now, ZoneOffset.UTC); }

    @Override public ZoneId getZone() { return ZoneOffset.UTC; }
    @Override public Clock withZone(ZoneId zone) { return this; }
    @Override public Instant instant() { return now; }
}
