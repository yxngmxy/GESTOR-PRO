package com.gestor.core;

import com.gestor.core.model.*;
import com.gestor.core.template.TemplateRegistry;
import com.gestor.core.util.IdGenerator;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static com.gestor.core.state.TaskStatus.*;
import static org.junit.jupiter.api.Assertions.*;

class PrototypePatternTest {
    IdGenerator ids, projectIds;
    TemplateRegistry registry;

    @BeforeEach
    void setUp() {
        ids = new IdGenerator();
        projectIds = new IdGenerator();
        registry = new TemplateRegistry(ids, projectIds);
    }

    private CompositeTask sprint() {
        CompositeTask s = new CompositeTask(ids.next(), "Sprint");
        SimpleTask planning = new SimpleTask(ids.next(), "Planning");
        planning.setDueDate(LocalDateTime.of(2026, 3, 2, 10, 0));
        planning.setAssignees(List.of("ana"));
        s.add(planning);
        s.setDueDate(LocalDateTime.of(2026, 3, 2, 10, 0));
        return s;
    }

    @Test
    void instantiatingTwiceGivesIndependentCopies() {
        registry.saveTask("sprint", sprint());
        Task a = registry.instantiateTask("sprint", null);
        Task b = registry.instantiateTask("Sprint", null); // el nombre no distingue mayúsculas
        assertNotSame(a, b);
        assertNotEquals(a.id(), b.id());
        assertNotEquals(a.children().get(0).id(), b.children().get(0).id());
        a.children().get(0).setPriority(Priority.URGENT);
        assertEquals(Priority.MEDIUM, b.children().get(0).priority());
    }

    @Test
    void templateIsNotAffectedByLaterChangesToTheSource() {
        CompositeTask original = sprint();
        registry.saveTask("sprint", original);
        original.children().get(0).setTitle("Cambiado");
        assertEquals("Planning", registry.instantiateTask("sprint", null).children().get(0).title());
    }

    @Test
    void copiesStartPendingEvenIfSourceWasDone() {
        CompositeTask s = sprint();
        SimpleTask only = (SimpleTask) s.children().get(0);
        only.moveTo(IN_PROGRESS); only.moveTo(IN_REVIEW); only.moveTo(DONE);
        registry.saveTask("sprint", s);
        assertEquals(PENDING, registry.instantiateTask("sprint", null).children().get(0).status());
    }

    @Test
    void datesShiftTogetherWhenNewDueIsGiven() {
        registry.saveTask("sprint", sprint());
        Task t = registry.instantiateTask("sprint", LocalDateTime.of(2026, 3, 16, 10, 0));
        assertEquals(LocalDateTime.of(2026, 3, 16, 10, 0), t.dueDate());
        assertEquals(LocalDateTime.of(2026, 3, 16, 10, 0), t.children().get(0).dueDate());
    }

    @Test
    void unknownTemplateFails() {
        assertThrows(IllegalArgumentException.class, () -> registry.instantiateTask("nada", null));
        assertThrows(IllegalArgumentException.class, () -> registry.instantiateProject("nada", "x", null));
    }

    @Test
    void projectTemplateAnchorsEarliestDateToStart() {
        Project p = new Project(projectIds.next(), "Mensual", new CompositeTask(0, "Mensual"));
        SimpleTask a = new SimpleTask(ids.next(), "Cierre");
        a.setDueDate(LocalDateTime.of(2026, 1, 31, 18, 0));
        SimpleTask b = new SimpleTask(ids.next(), "Reporte");
        b.setDueDate(LocalDateTime.of(2026, 2, 5, 18, 0));
        p.root().add(a); p.root().add(b);
        registry.saveProject("mensual", p);

        Project feb = registry.instantiateProject("mensual", "Febrero", LocalDateTime.of(2026, 2, 28, 18, 0));
        assertEquals("Febrero", feb.name());
        assertNotEquals(p.id(), feb.id());
        assertEquals(LocalDateTime.of(2026, 2, 28, 18, 0), feb.tasks().get(0).dueDate());
        assertEquals(LocalDateTime.of(2026, 3, 5, 18, 0), feb.tasks().get(1).dueDate());
        assertEquals(LocalDateTime.of(2026, 1, 31, 18, 0), a.dueDate(), "el original no se toca");
    }
}
