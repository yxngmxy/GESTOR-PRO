package com.gestor.core;

import com.gestor.core.model.CompositeTask;
import com.gestor.core.model.SimpleTask;
import com.gestor.core.state.InvalidTransitionException;
import com.gestor.core.state.TaskState;
import com.gestor.core.state.TaskStatus;
import org.junit.jupiter.api.Test;

import java.util.Set;

import static com.gestor.core.state.TaskStatus.*;
import static org.junit.jupiter.api.Assertions.*;

class StatePatternTest {

    @Test
    void eachStateDeclaresItsAllowedTransitions() {
        assertEquals(Set.of(IN_PROGRESS), TaskState.of(PENDING).allowedTransitions());
        assertEquals(Set.of(IN_REVIEW, PENDING), TaskState.of(IN_PROGRESS).allowedTransitions());
        assertEquals(Set.of(DONE, IN_PROGRESS), TaskState.of(IN_REVIEW).allowedTransitions());
        assertEquals(Set.of(IN_PROGRESS), TaskState.of(DONE).allowedTransitions());
    }

    @Test
    void validPathPendingToDone() {
        SimpleTask t = new SimpleTask(1, "x");
        t.moveTo(IN_PROGRESS);
        t.moveTo(IN_REVIEW);
        t.moveTo(DONE);
        assertEquals(DONE, t.status());
    }

    @Test
    void cannotSkipStates() {
        SimpleTask t = new SimpleTask(1, "x");
        InvalidTransitionException ex = assertThrows(InvalidTransitionException.class, () -> t.moveTo(DONE));
        assertTrue(ex.getMessage().contains("Pendiente"));
        assertEquals(PENDING, t.status(), "una transición inválida no debe alterar el estado");
        assertThrows(InvalidTransitionException.class, () -> t.moveTo(IN_REVIEW));
    }

    @Test
    void sameStateIsRejected() {
        SimpleTask t = new SimpleTask(1, "x");
        assertThrows(InvalidTransitionException.class, () -> t.moveTo(PENDING));
    }

    @Test
    void doneCanOnlyBeReopened() {
        SimpleTask t = new SimpleTask(1, "x");
        t.moveTo(IN_PROGRESS); t.moveTo(IN_REVIEW); t.moveTo(DONE);
        assertThrows(InvalidTransitionException.class, () -> t.moveTo(PENDING));
        t.moveTo(IN_PROGRESS);
        assertEquals(IN_PROGRESS, t.status());
    }

    @Test
    void compositeCannotBeDoneWhileChildrenAreNot() {
        CompositeTask group = new CompositeTask(1, "grupo");
        SimpleTask child = new SimpleTask(2, "hija");
        group.add(child);
        group.moveTo(IN_PROGRESS);
        group.moveTo(IN_REVIEW);
        assertThrows(InvalidTransitionException.class, () -> group.moveTo(DONE));

        child.moveTo(IN_PROGRESS); child.moveTo(IN_REVIEW); child.moveTo(DONE);
        group.moveTo(DONE);
        assertEquals(DONE, group.status());
    }

    @Test
    void statusParsingAcceptsSpanishAndAccents() {
        assertEquals(IN_REVIEW, TaskStatus.parse("En revisión"));
        assertEquals(IN_PROGRESS, TaskStatus.parse("en curso"));
        assertEquals(DONE, TaskStatus.parse("TERMINADA"));
        assertThrows(IllegalArgumentException.class, () -> TaskStatus.parse("nada"));
    }
}
