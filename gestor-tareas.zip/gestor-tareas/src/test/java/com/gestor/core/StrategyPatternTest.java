package com.gestor.core;

import com.gestor.core.model.*;
import com.gestor.core.query.*;
import com.gestor.core.state.TaskStatus;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

import static org.junit.jupiter.api.Assertions.*;

class StrategyPatternTest {
    TestClock clock = new TestClock(LocalDateTime.of(2026, 11, 20, 9, 0));
    SimpleTask a, b, c, d;
    List<Task> tasks;

    @BeforeEach
    void setUp() {
        a = new SimpleTask(1, "a"); a.setPriority(Priority.LOW);    a.setDueDate(LocalDateTime.of(2026, 12, 1, 0, 0)); a.setAssignees(List.of("Zoe"));
        b = new SimpleTask(2, "b"); b.setPriority(Priority.URGENT); b.setDueDate(LocalDateTime.of(2026, 11, 1, 0, 0)); b.setAssignees(List.of("ana"));
        c = new SimpleTask(3, "c"); c.setPriority(Priority.HIGH);   /* sin fecha, sin responsable */
        d = new SimpleTask(4, "d"); d.setPriority(Priority.MEDIUM); d.setDueDate(LocalDateTime.of(2026, 11, 25, 0, 0)); d.setAssignees(List.of("Beto"));
        tasks = List.of(a, b, c, d);
    }

    private static String titles(List<Task> l) {
        return l.stream().map(Task::title).collect(Collectors.joining());
    }

    @Test
    void sortByPriorityPutsMostImportantFirst() {
        assertEquals("bcda", titles(TaskQuery.all().sortedBy(new PrioritySort()).select(tasks)));
    }

    @Test
    void sortByDueDateNullsLast() {
        assertEquals("bdac", titles(TaskQuery.all().sortedBy(new DueDateSort()).select(tasks)));
    }

    @Test
    void sortByAssigneeIsAlphabeticalIgnoringCaseAndEmptyLast() {
        assertEquals("bdac", titles(TaskQuery.all().sortedBy(new AssigneeSort()).select(tasks)));
    }

    @Test
    void noSortKeepsOriginalOrder() {
        assertEquals("abcd", titles(TaskQuery.all().select(tasks)));
    }

    @Test
    void reversedInvertsTheChosenStrategy() {
        assertEquals("adcb", titles(TaskQuery.all().sortedBy(new PrioritySort()).reversed().select(tasks)));
    }

    @Test
    void strategiesAreInterchangeableByName() {
        assertEquals("prioridad", SortStrategies.byName("Prioridad").name());
        assertEquals("fecha", SortStrategies.byName("date").name());
        assertThrows(IllegalArgumentException.class, () -> SortStrategies.byName("color"));
    }

    @Test
    void filtersCombineWithAnd() {
        TaskQuery q = TaskQuery.all().where(Filters.minPriority(Priority.MEDIUM)).where(Filters.overdue(clock));
        assertEquals("b", titles(q.select(tasks)));
    }

    @Test
    void filterByAssigneeAndStatus() {
        assertEquals("b", titles(TaskQuery.all().where(Filters.assignee("ANA")).select(tasks)));
        d.moveTo(TaskStatus.IN_PROGRESS);
        assertEquals("d", titles(TaskQuery.all().where(Filters.status(TaskStatus.IN_PROGRESS)).select(tasks)));
    }

    @Test
    void groupStaysVisibleWhenOneOfItsChildrenMatches() {
        CompositeTask g = new CompositeTask(10, "grupo");
        g.add(a); g.add(b);
        TaskQuery q = TaskQuery.all().where(Filters.assignee("ana"));
        assertEquals("grupo", titles(q.select(List.of(g))));
        assertEquals("b", titles(q.select(g.children())));
        assertEquals("b", titles(q.flat(List.of(g))));
    }
}
