package com.gestor.core;

import com.gestor.core.command.*;
import com.gestor.core.model.*;
import com.gestor.core.notify.EventPublisher;
import com.gestor.core.state.InvalidTransitionException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Clock;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import static com.gestor.core.state.TaskStatus.*;
import static org.junit.jupiter.api.Assertions.*;

class CommandPatternTest {
    CommandHistory history;
    EventPublisher events;
    CompositeTask root;

    @BeforeEach
    void setUp() {
        history = new CommandHistory();
        events = new EventPublisher(Clock.systemUTC());
        root = new CompositeTask(0, "raiz");
    }

    @Test
    void addUndoRedo() {
        SimpleTask t = new SimpleTask(1, "t");
        history.execute(new AddTaskCommand(root, t, events));
        assertEquals(1, root.children().size());

        assertTrue(history.undo().isPresent());
        assertTrue(root.children().isEmpty());
        assertNull(t.parent());

        assertTrue(history.redo().isPresent());
        assertEquals(List.of(t), root.children());
    }

    @Test
    void newActionClearsRedoStack() {
        history.execute(new AddTaskCommand(root, new SimpleTask(1, "a"), events));
        history.undo();
        assertTrue(history.canRedo());
        history.execute(new AddTaskCommand(root, new SimpleTask(2, "b"), events));
        assertFalse(history.canRedo());
    }

    @Test
    void undoRedoOnEmptyHistoryDoNothing() {
        assertTrue(history.undo().isEmpty());
        assertTrue(history.redo().isEmpty());
    }

    @Test
    void failedCommandIsNotRecorded() {
        SimpleTask t = new SimpleTask(1, "t");
        root.add(t);
        assertThrows(InvalidTransitionException.class, () -> history.execute(new ChangeStatusCommand(t, DONE, events)));
        assertFalse(history.canUndo());
        assertEquals(PENDING, t.status());
    }

    @Test
    void changeStatusIsUndoable() {
        SimpleTask t = new SimpleTask(1, "t");
        root.add(t);
        history.execute(new ChangeStatusCommand(t, IN_PROGRESS, events));
        history.execute(new ChangeStatusCommand(t, IN_REVIEW, events));
        history.undo();
        assertEquals(IN_PROGRESS, t.status());
        history.undo();
        assertEquals(PENDING, t.status());
        history.redo();
        assertEquals(IN_PROGRESS, t.status());
    }

    @Test
    void removeRestoresSamePositionAndSubtasks() {
        SimpleTask a = new SimpleTask(1, "a");
        CompositeTask b = new CompositeTask(2, "b");
        SimpleTask b1 = new SimpleTask(3, "b1");
        SimpleTask c = new SimpleTask(4, "c");
        root.add(a); root.add(b); root.add(c); b.add(b1);

        history.execute(new RemoveTaskCommand(b, events));
        assertEquals(List.of(a, c), root.children());

        history.undo();
        assertEquals(List.of(a, b, c), root.children());
        assertEquals(List.of(b1), b.children());
    }

    @Test
    void rootCannotBeRemoved() {
        assertThrows(IllegalArgumentException.class, () -> new RemoveTaskCommand(root, events));
    }

    @Test
    void propertyChangeAndAssignRoundTrip() {
        SimpleTask t = new SimpleTask(1, "t");
        root.add(t);
        history.execute(new PropertyChangeCommand<>("prio", t.priority(), Priority.URGENT, t::setPriority));
        history.execute(new AssignCommand(t, List.of("ana", "luis"), events));
        assertEquals(Priority.URGENT, t.priority());
        assertEquals(Set.of("ana", "luis"), t.assignees());
        history.undo();
        assertTrue(t.assignees().isEmpty());
        history.undo();
        assertEquals(Priority.MEDIUM, t.priority());
    }

    @Test
    void commandsPublishEvents() {
        List<String> seen = new ArrayList<>();
        events.subscribe(e -> seen.add(e.type().name()));
        SimpleTask t = new SimpleTask(1, "t");
        t.setAssignees(List.of("ana"));
        history.execute(new AddTaskCommand(root, t, events));
        history.execute(new ChangeStatusCommand(t, IN_PROGRESS, events));
        assertEquals(List.of("TASK_CREATED", "STATUS_CHANGED"), seen);
    }
}
