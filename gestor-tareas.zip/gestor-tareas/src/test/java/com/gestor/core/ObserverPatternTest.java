package com.gestor.core;

import com.gestor.core.model.*;
import com.gestor.core.notify.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import static com.gestor.core.state.TaskStatus.*;
import static org.junit.jupiter.api.Assertions.*;

class ObserverPatternTest {
    TestClock clock;
    EventPublisher publisher;
    UserInbox inbox;
    DeadlineChecker checker;
    Project project;
    SimpleTask task;

    @BeforeEach
    void setUp() {
        clock = new TestClock(LocalDateTime.of(2026, 11, 20, 9, 0));
        publisher = new EventPublisher(clock);
        inbox = new UserInbox();
        publisher.subscribe(inbox);
        checker = new DeadlineChecker(clock, publisher, Duration.ofHours(24));
        CompositeTask root = new CompositeTask(0, "p");
        project = new Project(1, "p", root);
        task = new SimpleTask(1, "Entrega");
        task.setAssignees(List.of("ana", "luis"));
        root.add(task);
    }

    @Test
    void allSubscribersReceiveEveryEvent() {
        List<String> a = new ArrayList<>(), b = new ArrayList<>();
        publisher.subscribe(e -> a.add(e.message()));
        publisher.subscribe(e -> b.add(e.message()));
        publisher.emit(EventType.ASSIGNED, task, task.assignees(), "hola");
        assertEquals(List.of("hola"), a);
        assertEquals(List.of("hola"), b);
    }

    @Test
    void unsubscribedListenerStopsReceiving() {
        List<String> seen = new ArrayList<>();
        TaskListener l = e -> seen.add(e.message());
        publisher.subscribe(l);
        publisher.emit(EventType.ASSIGNED, task, task.assignees(), "1");
        publisher.unsubscribe(l);
        publisher.emit(EventType.ASSIGNED, task, task.assignees(), "2");
        assertEquals(List.of("1"), seen);
    }

    @Test
    void faultyListenerDoesNotBreakOthers() {
        publisher.subscribe(e -> { throw new RuntimeException("boom"); });
        publisher.emit(EventType.ASSIGNED, task, task.assignees(), "x");
        assertEquals(1, inbox.messagesFor("ana").size());
    }

    @Test
    void noAlertWhenDeadlineIsFarAway() {
        task.setDueDate(clock.nowLocal().plusDays(5));
        assertTrue(checker.check(List.of(project)).isEmpty());
    }

    @Test
    void dueSoonAlertReachesAllAssigneesOnlyOnce() {
        task.setDueDate(clock.nowLocal().plusHours(5));
        List<TaskEvent> first = checker.check(List.of(project));
        assertEquals(1, first.size());
        assertEquals(EventType.DUE_SOON, first.get(0).type());
        assertEquals(1, inbox.messagesFor("ana").size());
        assertEquals(1, inbox.messagesFor("luis").size());

        assertTrue(checker.check(List.of(project)).isEmpty(), "no se repite el mismo aviso");
    }

    @Test
    void overdueAlertAppearsWhenTimePasses() {
        task.setDueDate(clock.nowLocal().plusHours(5));
        checker.check(List.of(project));                // DUE_SOON
        clock.advance(Duration.ofHours(6));
        List<TaskEvent> later = checker.check(List.of(project));
        assertEquals(1, later.size());
        assertEquals(EventType.OVERDUE, later.get(0).type());
        assertEquals(2, inbox.messagesFor("ana").size());
    }

    @Test
    void finishedTasksAndTasksWithoutDateAreIgnored() {
        task.setDueDate(clock.nowLocal().minusDays(1));
        task.moveTo(IN_PROGRESS); task.moveTo(IN_REVIEW); task.moveTo(DONE);
        assertTrue(checker.check(List.of(project)).isEmpty());

        SimpleTask other = new SimpleTask(2, "sin fecha");
        project.root().add(other);
        assertTrue(checker.check(List.of(project)).isEmpty());
    }

    @Test
    void taskWithoutAssigneesProducesEventWithNoRecipients() {
        SimpleTask lonely = new SimpleTask(2, "huérfana");
        lonely.setDueDate(clock.nowLocal().minusHours(1));
        project.root().add(lonely);
        List<TaskEvent> ev = checker.check(List.of(project));
        assertEquals(1, ev.size());
        assertTrue(ev.get(0).recipients().isEmpty());
        assertTrue(inbox.all().isEmpty());
    }
}
