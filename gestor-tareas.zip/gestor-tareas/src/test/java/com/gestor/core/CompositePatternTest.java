package com.gestor.core;

import com.gestor.core.model.*;
import com.gestor.core.util.IdGenerator;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;

import static com.gestor.core.state.TaskStatus.*;
import static org.junit.jupiter.api.Assertions.*;

class CompositePatternTest {

    @Test
    void progressIsAveragedOverChildren() {
        CompositeTask g = new CompositeTask(1, "g");
        SimpleTask a = new SimpleTask(2, "a"), b = new SimpleTask(3, "b");
        g.add(a); g.add(b);
        assertEquals(0.0, g.progress());
        a.moveTo(IN_PROGRESS); a.moveTo(IN_REVIEW); a.moveTo(DONE);
        assertEquals(0.5, g.progress(), 1e-9);
    }

    @Test
    void nestedCompositesAreTreatedUniformly() {
        CompositeTask root = new CompositeTask(1, "r");
        CompositeTask mid = new CompositeTask(2, "m");
        SimpleTask leaf = new SimpleTask(3, "l");
        root.add(mid); mid.add(leaf);
        assertEquals(3, root.flatten().size());
        assertTrue(root.find(3).isPresent());
        assertSame(mid, leaf.parent());
    }

    @Test
    void cannotCreateCycles() {
        CompositeTask a = new CompositeTask(1, "a");
        CompositeTask b = new CompositeTask(2, "b");
        a.add(b);
        assertThrows(IllegalArgumentException.class, () -> a.add(a));
        b.remove(b); // no-op
        CompositeTask c = new CompositeTask(3, "c");
        c.add(a);
        assertThrows(IllegalStateException.class, () -> b.add(a), "a ya tiene padre");
    }

    @Test
    void simpleTaskRejectsChildren() {
        SimpleTask t = new SimpleTask(1, "t");
        assertTrue(t.children().isEmpty());
        assertFalse(t.isComposite());
    }

    @Test
    void blankTitleIsRejected() {
        assertThrows(IllegalArgumentException.class, () -> new SimpleTask(1, "  "));
    }

    @Test
    void deepCopyIsIndependentWithNewIdsAndPendingState() {
        CompositeTask g = new CompositeTask(1, "g");
        SimpleTask a = new SimpleTask(2, "a");
        a.setPriority(Priority.HIGH);
        a.setAssignees(List.of("ana"));
        g.add(a);
        a.moveTo(IN_PROGRESS);

        IdGenerator ids = new IdGenerator();
        for (int i = 0; i < 10; i++) ids.next();
        Task copy = g.deepCopy(ids);

        assertNotEquals(g.id(), copy.id());
        Task copyChild = copy.children().get(0);
        assertNotEquals(a.id(), copyChild.id());
        assertEquals(PENDING, copyChild.status(), "la copia siempre empieza pendiente");
        assertEquals(Priority.HIGH, copyChild.priority());
        assertEquals(a.assignees(), copyChild.assignees());

        copyChild.setPriority(Priority.LOW);
        copyChild.setAssignees(List.of("luis"));
        assertEquals(Priority.HIGH, a.priority(), "modificar la copia no afecta al original");
        assertEquals(List.of("ana"), List.copyOf(a.assignees()));
    }

    @Test
    void shiftDueDatesMovesWholeTree() {
        CompositeTask g = new CompositeTask(1, "g");
        SimpleTask a = new SimpleTask(2, "a");
        g.add(a);
        g.setDueDate(LocalDateTime.of(2026, 1, 10, 9, 0));
        a.setDueDate(LocalDateTime.of(2026, 1, 12, 9, 0));
        g.shiftDueDates(java.time.Duration.ofDays(5));
        assertEquals(LocalDateTime.of(2026, 1, 15, 9, 0), g.dueDate());
        assertEquals(LocalDateTime.of(2026, 1, 17, 9, 0), a.dueDate());
    }
}
