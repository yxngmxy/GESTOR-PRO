package com.gestor.cli;

import com.gestor.core.service.TaskManager;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

/** La consola es una capa fina sobre el mismo núcleo que usa la GUI. */
class ConsoleAppTest {

    private String run(String script) {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();
        PrintStream out = new PrintStream(buf, true, StandardCharsets.UTF_8);
        TaskManager tm = new TaskManager();
        new ConsoleApp(tm, new ByteArrayInputStream(script.getBytes(StandardCharsets.UTF_8)), out).run();
        return buf.toString(StandardCharsets.UTF_8);
    }

    @Test
    void createListAndChangeStatus() {
        String o = run("proyecto Web\nnueva Diseño grupo prioridad=alta\nnueva Maqueta en=1 resp=ana,luis\n"
                + "estado 2 en curso\nlistar\nsalir\n");
        assertTrue(o.contains("Creada #1 Diseño"));
        assertTrue(o.contains("#2 [En curso] Maqueta"));
        assertTrue(o.contains("ana, luis"));
    }

    @Test
    void invalidTransitionShowsFriendlyError() {
        String o = run("proyecto P\nnueva A\nestado 1 terminada\nsalir\n");
        assertTrue(o.contains("Error: Transición no permitida"));
    }

    @Test
    void undoAndRedoFromConsole() {
        String o = run("proyecto P\nnueva A\nprioridad 1 urgente\ndeshacer\nver 1\nrehacer\nsalir\n");
        assertTrue(o.contains("Deshecho: Prioridad de 'A' a Urgente"));
        assertTrue(o.contains("Rehecho:"));
    }

    @Test
    void sortAndFilterOptions() {
        String o = run("proyecto P\nnueva baja prioridad=baja\nnueva alta prioridad=alta\nlistar orden=prioridad\nlistar prioridad=alta\nsalir\n");
        int firstList = o.indexOf("alta  · Alta");
        int lowInFirstList = o.indexOf("baja  · Baja", o.indexOf("(0% completo)"));
        assertTrue(firstList >= 0 && lowInFirstList > firstList, "alta debe aparecer antes que baja");
        assertEquals(2, o.split("#2 \\[Pendiente\\] alta").length - 1, "la tarea alta se lista dos veces (orden y filtro)");
    }

    @Test
    void templatesFromConsole() {
        String o = run("proyecto P\nnueva G grupo\nnueva H en=1\nplantilla guardar sprint 1\nplantilla usar sprint\nplantillas\nsalir\n");
        assertTrue(o.contains("Plantilla de tarea 'sprint' guardada."));
        assertTrue(o.contains("Creada desde plantilla:"));
        assertTrue(o.contains("[sprint]"));
    }

    @Test
    void unknownCommandAndMissingProject() {
        String o = run("volar\nnueva X\nsalir\n");
        assertTrue(o.contains("Comando desconocido"));
        assertTrue(o.contains("No hay proyecto seleccionado"));
    }

    @Test
    void quotedTitlesKeepSpaces() {
        String o = run("proyecto P\nnueva \"Escribir informe final\" prioridad=media\nsalir\n");
        assertTrue(o.contains("Creada #1 Escribir informe final"));
    }
}
