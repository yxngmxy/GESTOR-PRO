package com.gestor.gui;

import com.gestor.core.model.Priority;
import com.gestor.core.model.Project;
import com.gestor.core.model.Task;
import com.gestor.core.notify.EventType;
import com.gestor.core.query.Filters;
import com.gestor.core.query.SortStrategies;
import com.gestor.core.query.SortStrategy;
import com.gestor.core.query.TaskQuery;
import com.gestor.core.service.DemoData;
import com.gestor.core.service.TaskManager;
import com.gestor.core.state.TaskStatus;
import com.gestor.core.util.Dates;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Interfaz gráfica Swing. Igual que la consola, no contiene reglas de negocio:
 * toda acción pasa por {@link TaskManager}, el mismo núcleo que usa la versión de consola.
 */
public class GuiApp extends JFrame {
    private final TaskManager tm;

    // proyecto y árbol
    private final DefaultComboBoxModel<Project> projectModel = new DefaultComboBoxModel<>();
    private final JComboBox<Project> projectCombo = new JComboBox<>(projectModel);
    private boolean updatingProjects;
    private final DefaultTreeModel treeModel = new DefaultTreeModel(new DefaultMutableTreeNode());
    private final JTree tree = new JTree(treeModel);

    // barra de orden / filtros
    private final JComboBox<SortStrategy> sortCombo = new JComboBox<>(SortStrategies.all().toArray(new SortStrategy[0]));
    private final JCheckBox descending = new JCheckBox("Invertir");
    private final JComboBox<Object> statusFilter = new JComboBox<>();
    private final JComboBox<Object> priorityFilter = new JComboBox<>();
    private final JTextField assigneeFilter = new JTextField(7);
    private final JTextField textFilter = new JTextField(7);

    // historial
    private final JButton undoBtn = new JButton("Deshacer");
    private final JButton redoBtn = new JButton("Rehacer");

    // detalle
    private final JLabel idLabel = new JLabel("-");
    private final JTextField titleField = new JTextField(18);
    private final JComboBox<TaskStatus> statusBox = new JComboBox<>();
    private final JComboBox<Priority> priorityBox = new JComboBox<>(Priority.values());
    private final JTextField dueField = new JTextField(14);
    private final JTextField assigneesField = new JTextField(18);
    private final JTextArea descriptionArea = new JTextArea(4, 18);
    private final JButton applyBtn = new JButton("Aplicar cambios");

    // alertas
    private final JTextArea alertsArea = new JTextArea(6, 40);
    private final JLabel statusBar = new JLabel(" ");

    public GuiApp(TaskManager tm) {
        super("Gestor de tareas y proyectos");
        this.tm = tm;
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        buildUi();
        wireEvents();
        reloadProjects();
        setSize(1200, 720);
        setLocationRelativeTo(null);
    }

    // =================================================================== construcción de la UI
    private void buildUi() {
        // --- fila 1: proyecto, historial y plantillas
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        top.add(new JLabel("Proyecto:"));
        top.add(projectCombo);
        projectCombo.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean s, boolean f) {
                return super.getListCellRendererComponent(l, v instanceof Project p ? p.name() : v, i, s, f);
            }
        });
        top.add(button("Nuevo proyecto", e -> newProject()));
        top.add(templatesMenuButton());
        top.add(Box.createHorizontalStrut(16));
        top.add(undoBtn);
        top.add(redoBtn);

        // --- fila 2: acciones sobre tareas
        JPanel actions = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        actions.add(button("Nueva tarea", e -> newTask(false, false)));
        actions.add(button("Nueva tarea compuesta", e -> newTask(true, false)));
        actions.add(button("Nueva subtarea", e -> newTask(false, true)));
        actions.add(button("Eliminar", e -> deleteSelected()));

        // --- fila 3: orden y filtros
        JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 3));
        statusFilter.addItem("Todos");
        for (TaskStatus s : TaskStatus.values()) statusFilter.addItem(s);
        priorityFilter.addItem("Todas");
        for (Priority p : Priority.values()) priorityFilter.addItem(p);
        sortCombo.setRenderer(new DefaultListCellRenderer() {
            @Override public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean s, boolean f) {
                String name = v instanceof SortStrategy st ? st.name() : String.valueOf(v);
                return super.getListCellRendererComponent(l, name.substring(0, 1).toUpperCase() + name.substring(1), i, s, f);
            }
        });
        filters.add(new JLabel("Ordenar por:"));
        filters.add(sortCombo);
        filters.add(descending);
        filters.add(new JLabel("  Estado:"));
        filters.add(statusFilter);
        filters.add(new JLabel("Prioridad ≥"));
        filters.add(priorityFilter);
        filters.add(new JLabel("Responsable:"));
        filters.add(assigneeFilter);
        filters.add(new JLabel("Texto:"));
        filters.add(textFilter);
        filters.add(button("Limpiar", e -> clearFilters()));

        JPanel north = new JPanel();
        north.setLayout(new BoxLayout(north, BoxLayout.Y_AXIS));
        for (JPanel row : List.of(top, actions, filters)) {
            row.setAlignmentX(Component.LEFT_ALIGNMENT);
            north.add(row);
        }

        // --- árbol
        tree.setRootVisible(true);
        tree.setCellRenderer(new TaskTreeRenderer(tm.clock()));
        tree.getSelectionModel().setSelectionMode(javax.swing.tree.TreeSelectionModel.SINGLE_TREE_SELECTION);

        // --- detalle
        JPanel detail = new JPanel(new GridBagLayout());
        detail.setBorder(BorderFactory.createTitledBorder("Detalle de la tarea"));
        int row = 0;
        addRow(detail, row++, "Id", idLabel);
        addRow(detail, row++, "Título", titleField);
        addRow(detail, row++, "Estado", statusBox);
        addRow(detail, row++, "Prioridad", priorityBox);
        addRow(detail, row++, "Límite (aaaa-mm-dd [hh:mm])", dueField);
        addRow(detail, row++, "Responsables (coma)", assigneesField);
        descriptionArea.setLineWrap(true);
        addRow(detail, row++, "Descripción", new JScrollPane(descriptionArea));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 1; c.gridy = row; c.anchor = GridBagConstraints.EAST; c.insets = new Insets(8, 4, 4, 4);
        detail.add(applyBtn, c);
        JPanel detailWrap = new JPanel(new BorderLayout());
        detailWrap.add(detail, BorderLayout.NORTH);

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, new JScrollPane(tree), detailWrap);
        split.setResizeWeight(0.65);

        // --- alertas
        alertsArea.setEditable(false);
        JPanel alerts = new JPanel(new BorderLayout());
        alerts.setBorder(BorderFactory.createTitledBorder("Avisos a responsables"));
        alerts.add(new JScrollPane(alertsArea), BorderLayout.CENTER);
        JPanel alertButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        alertButtons.add(button("Revisar fechas límite ahora", e -> checkDeadlines(true)));
        alertButtons.add(button("Limpiar avisos", e -> { alertsArea.setText(""); tm.inbox().clear(); }));
        alerts.add(alertButtons, BorderLayout.SOUTH);

        JPanel south = new JPanel(new BorderLayout());
        south.add(alerts, BorderLayout.CENTER);
        south.add(statusBar, BorderLayout.SOUTH);
        statusBar.setBorder(BorderFactory.createEmptyBorder(2, 6, 2, 6));

        getContentPane().add(north, BorderLayout.NORTH);
        getContentPane().add(split, BorderLayout.CENTER);
        getContentPane().add(south, BorderLayout.SOUTH);
    }

    private static void addRow(JPanel p, int row, String label, JComponent field) {
        GridBagConstraints l = new GridBagConstraints();
        l.gridx = 0; l.gridy = row; l.anchor = GridBagConstraints.WEST; l.insets = new Insets(3, 4, 3, 8);
        p.add(new JLabel(label), l);
        GridBagConstraints f = new GridBagConstraints();
        f.gridx = 1; f.gridy = row; f.weightx = 1; f.fill = GridBagConstraints.HORIZONTAL; f.insets = new Insets(3, 0, 3, 4);
        p.add(field, f);
    }

    private static JButton button(String text, java.awt.event.ActionListener l) {
        JButton b = new JButton(text);
        b.addActionListener(l);
        return b;
    }

    private JButton templatesMenuButton() {
        JPopupMenu menu = new JPopupMenu();
        menu.add(menuItem("Guardar tarea seleccionada como plantilla…", this::saveTaskTemplate));
        menu.add(menuItem("Insertar tarea desde plantilla…", this::insertTaskTemplate));
        menu.addSeparator();
        menu.add(menuItem("Guardar proyecto actual como plantilla…", this::saveProjectTemplate));
        menu.add(menuItem("Crear proyecto desde plantilla…", this::createProjectFromTemplate));
        JButton b = new JButton("Plantillas ▾");
        b.addActionListener(e -> menu.show(b, 0, b.getHeight()));
        return b;
    }

    private static JMenuItem menuItem(String text, Runnable r) {
        JMenuItem m = new JMenuItem(text);
        m.addActionListener(e -> r.run());
        return m;
    }

    // =================================================================== eventos
    private void wireEvents() {
        projectCombo.addActionListener(e -> { if (!updatingProjects) refresh(); });
        tree.addTreeSelectionListener(e -> fillDetails(selectedTask()));
        sortCombo.addActionListener(e -> refresh());
        descending.addActionListener(e -> refresh());
        statusFilter.addActionListener(e -> refresh());
        priorityFilter.addActionListener(e -> refresh());
        for (JTextField f : List.of(assigneeFilter, textFilter)) f.addActionListener(e -> refresh());
        undoBtn.addActionListener(e -> guard(() -> { tm.undo(); refresh(); }));
        redoBtn.addActionListener(e -> guard(() -> { tm.redo(); refresh(); }));
        applyBtn.addActionListener(e -> applyChanges());

        // atajos Ctrl+Z / Ctrl+Y
        JRootPane rp = getRootPane();
        rp.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("ctrl Z"), "undo");
        rp.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("ctrl Y"), "redo");
        rp.getActionMap().put("undo", new AbstractAction() { public void actionPerformed(ActionEvent e) { undoBtn.doClick(); } });
        rp.getActionMap().put("redo", new AbstractAction() { public void actionPerformed(ActionEvent e) { redoBtn.doClick(); } });

        // Observer: los avisos dirigidos a responsables aparecen en el panel
        tm.events().subscribe(ev -> {
            if (ev.recipients().isEmpty()) return;
            SwingUtilities.invokeLater(() -> alertsArea.append("[" + ev.type() + "] " + String.join(", ", ev.recipients())
                    + ": " + ev.message() + "\n"));
        });

        // revisión periódica de fechas límite (el reloj del núcleo decide qué está vencido)
        new javax.swing.Timer(30_000, e -> checkDeadlines(false)).start();
    }

    // =================================================================== acciones
    private void reloadProjects() {
        Project selected = (Project) projectCombo.getSelectedItem();
        updatingProjects = true;
        try {
            projectModel.removeAllElements();
            tm.projects().forEach(projectModel::addElement);
            if (selected != null && tm.projects().contains(selected)) projectModel.setSelectedItem(selected);
        } finally {
            updatingProjects = false;
        }
        refresh();
    }

    private void newProject() {
        String name = ask("Nombre del proyecto:");
        if (name == null) return;
        guard(() -> {
            Project p = tm.createProject(name);
            reloadProjects();
            projectCombo.setSelectedItem(p);
        });
    }

    private void newTask(boolean composite, boolean asChild) {
        Project p = currentProject();
        if (p == null) { info("Primero cree un proyecto."); return; }
        Task parent = asChild ? selectedTask() : null;
        if (asChild && parent == null) { info("Seleccione una tarea compuesta para agregarle una subtarea."); return; }
        String title = ask(composite ? "Título de la tarea compuesta:" : "Título:");
        if (title == null) return;
        guard(() -> { tm.addTask(p, parent, title, composite); refresh(); });
    }

    private void deleteSelected() {
        Task t = selectedTask();
        if (t == null) { info("Seleccione una tarea."); return; }
        guard(() -> { tm.remove(t); refresh(); });
    }

    private void applyChanges() {
        Task t = selectedTask();
        if (t == null) return;
        guard(() -> {
            if (!titleField.getText().trim().equals(t.title())) tm.rename(t, titleField.getText());
            if (priorityBox.getSelectedItem() != t.priority()) tm.setPriority(t, (Priority) priorityBox.getSelectedItem());
            java.time.LocalDateTime newDue = Dates.parse(dueField.getText());
            if (!java.util.Objects.equals(newDue, t.dueDate())) tm.setDueDate(t, newDue);
            var names = parseNames(assigneesField.getText());
            if (!names.equals(new LinkedHashSet<>(t.assignees()))) tm.assign(t, names);
            if (!descriptionArea.getText().equals(t.description())) tm.setDescription(t, descriptionArea.getText());
            TaskStatus target = (TaskStatus) statusBox.getSelectedItem();
            if (target != null && target != t.status()) tm.changeStatus(t, target); // puede rechazarse por las reglas
            refresh();
        });
    }

    private void checkDeadlines(boolean verbose) {
        int n = tm.checkDeadlines().size();
        if (verbose) setStatus(n == 0 ? "Sin alertas nuevas." : n + " alerta(s) nueva(s).");
    }

    private void saveTaskTemplate() {
        Task t = selectedTask();
        if (t == null) { info("Seleccione la tarea que servirá de plantilla."); return; }
        String name = ask("Nombre de la plantilla:");
        if (name == null) return;
        guard(() -> { tm.templates().saveTask(name, t); setStatus("Plantilla '" + name + "' guardada."); });
    }

    private void insertTaskTemplate() {
        Project p = currentProject();
        List<String> names = tm.templates().taskTemplateNames();
        if (p == null || names.isEmpty()) { info("No hay plantillas de tarea (o no hay proyecto)."); return; }
        String name = (String) JOptionPane.showInputDialog(this, "Plantilla:", "Insertar plantilla", JOptionPane.PLAIN_MESSAGE,
                null, names.toArray(), names.get(0));
        if (name == null) return;
        String due = ask("Nueva fecha límite (opcional, deje vacío para conservar las fechas):");
        Task parent = selectedTask() != null && selectedTask().isComposite() ? selectedTask() : null;
        guard(() -> { tm.addTaskFromTemplate(p, parent, name, due == null ? null : Dates.parse(due)); refresh(); });
    }

    private void saveProjectTemplate() {
        Project p = currentProject();
        if (p == null) return;
        String name = ask("Nombre de la plantilla de proyecto:");
        if (name == null) return;
        guard(() -> { tm.templates().saveProject(name, p); setStatus("Plantilla de proyecto '" + name + "' guardada."); });
    }

    private void createProjectFromTemplate() {
        List<String> names = tm.templates().projectTemplateNames();
        if (names.isEmpty()) { info("No hay plantillas de proyecto."); return; }
        String tpl = (String) JOptionPane.showInputDialog(this, "Plantilla:", "Crear proyecto", JOptionPane.PLAIN_MESSAGE,
                null, names.toArray(), names.get(0));
        if (tpl == null) return;
        String newName = ask("Nombre del nuevo proyecto:");
        if (newName == null) return;
        String start = ask("Fecha de inicio (opcional; desplaza las fechas de la plantilla):");
        guard(() -> {
            Project p = tm.createProjectFromTemplate(tpl, newName, start == null ? null : Dates.parse(start));
            reloadProjects();
            projectCombo.setSelectedItem(p);
        });
    }

    // =================================================================== vista
    private Project currentProject() { return (Project) projectCombo.getSelectedItem(); }

    private Task selectedTask() {
        TreePath path = tree.getSelectionPath();
        if (path == null) return null;
        Object o = ((DefaultMutableTreeNode) path.getLastPathComponent()).getUserObject();
        return o instanceof Task t ? t : null;
    }

    private TaskQuery buildQuery() {
        TaskQuery q = TaskQuery.all().sortedBy((SortStrategy) sortCombo.getSelectedItem());
        if (descending.isSelected()) q = q.reversed();
        if (statusFilter.getSelectedItem() instanceof TaskStatus s) q = q.where(Filters.status(s));
        if (priorityFilter.getSelectedItem() instanceof Priority p) q = q.where(Filters.minPriority(p));
        if (!assigneeFilter.getText().isBlank()) q = q.where(Filters.assignee(assigneeFilter.getText()));
        if (!textFilter.getText().isBlank()) q = q.where(Filters.titleContains(textFilter.getText()));
        return q;
    }

    private void clearFilters() {
        sortCombo.setSelectedIndex(0);
        descending.setSelected(false);
        statusFilter.setSelectedIndex(0);
        priorityFilter.setSelectedIndex(0);
        assigneeFilter.setText("");
        textFilter.setText("");
        refresh();
    }

    /** Reconstruye el árbol a partir del núcleo, conservando la selección. */
    private void refresh() {
        Project p = currentProject();
        Task previous = selectedTask();
        DefaultMutableTreeNode root = new DefaultMutableTreeNode(
                p == null ? "(cree un proyecto)" : p.name() + "  —  " + Math.round(p.progress() * 100) + "% completo");
        if (p != null) build(root, p.tasks(), buildQuery());
        treeModel.setRoot(root);
        for (int i = 0; i < tree.getRowCount(); i++) tree.expandRow(i);
        if (previous != null) selectNodeFor(root, previous.id());
        undoBtn.setEnabled(tm.history().canUndo());
        redoBtn.setEnabled(tm.history().canRedo());
        undoBtn.setToolTipText(tm.history().nextUndo().orElse("Nada que deshacer"));
        redoBtn.setToolTipText(tm.history().nextRedo().orElse("Nada que rehacer"));
        fillDetails(selectedTask());
    }

    private void build(DefaultMutableTreeNode parent, List<Task> siblings, TaskQuery q) {
        for (Task t : q.select(siblings)) {
            DefaultMutableTreeNode node = new DefaultMutableTreeNode(t);
            parent.add(node);
            build(node, t.children(), q);
        }
    }

    private void selectNodeFor(DefaultMutableTreeNode root, int taskId) {
        Enumeration<?> en = root.preorderEnumeration();
        while (en.hasMoreElements()) {
            DefaultMutableTreeNode n = (DefaultMutableTreeNode) en.nextElement();
            if (n.getUserObject() instanceof Task t && t.id() == taskId) {
                tree.setSelectionPath(new TreePath(n.getPath()));
                return;
            }
        }
    }

    private void fillDetails(Task t) {
        boolean has = t != null;
        for (JComponent c : List.of(titleField, statusBox, priorityBox, dueField, assigneesField, descriptionArea, applyBtn))
            c.setEnabled(has);
        if (!has) {
            idLabel.setText("-");
            titleField.setText(""); dueField.setText(""); assigneesField.setText(""); descriptionArea.setText("");
            statusBox.removeAllItems();
            return;
        }
        idLabel.setText("#" + t.id() + (t.isComposite() ? "  (compuesta)" : "  (simple)"));
        titleField.setText(t.title());
        statusBox.removeAllItems();
        statusBox.addItem(t.status()); // el estado actual + solo los destinos que permite el State
        t.state().allowedTransitions().forEach(statusBox::addItem);
        statusBox.setSelectedItem(t.status());
        priorityBox.setSelectedItem(t.priority());
        dueField.setText(t.dueDate() == null ? "" : Dates.format(t.dueDate()));
        assigneesField.setText(String.join(", ", t.assignees()));
        descriptionArea.setText(t.description());
    }

    // =================================================================== utilidades
    private static LinkedHashSet<String> parseNames(String csv) {
        return Arrays.stream(csv.split("[,;]")).map(String::trim).filter(s -> !s.isEmpty())
                .collect(Collectors.toCollection(LinkedHashSet::new));
    }

    private String ask(String message) {
        String s = JOptionPane.showInputDialog(this, message);
        return s == null ? null : s.trim();
    }

    private void info(String msg) { JOptionPane.showMessageDialog(this, msg); }

    private void setStatus(String msg) { statusBar.setText(msg); }

    /** Ejecuta una acción mostrando como mensaje cualquier error de reglas (transición inválida, fecha mal escrita...). */
    private void guard(Runnable action) {
        try {
            action.run();
            setStatus(" ");
        } catch (IllegalArgumentException | IllegalStateException | UnsupportedOperationException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "No se pudo realizar la acción", JOptionPane.WARNING_MESSAGE);
            refresh();
        }
    }

    // =================================================================== main
    public static void main(String[] args) {
        TaskManager tm = new TaskManager();
        if (Arrays.asList(args).contains("--demo")) DemoData.load(tm);
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); } catch (Exception ignored) {}
            new GuiApp(tm).setVisible(true);
        });
    }
}
