package com.gestor.gui;

import com.gestor.core.model.Task;
import com.gestor.core.query.Filters;
import com.gestor.core.util.Dates;

import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.time.Clock;
import java.util.function.Predicate;

/** Dibuja cada tarea del árbol; las vencidas se muestran en rojo y las terminadas en gris. */
class TaskTreeRenderer extends DefaultTreeCellRenderer {
    private final Predicate<Task> overdue;

    TaskTreeRenderer(Clock clock) {
        this.overdue = Filters.overdue(clock);
    }

    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded,
                                                  boolean leaf, int row, boolean hasFocus) {
        super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);
        Object o = ((DefaultMutableTreeNode) value).getUserObject();
        if (o instanceof Task t) {
            StringBuilder sb = new StringBuilder();
            sb.append(t.title()).append("   [").append(t.status()).append("]  ·  ").append(t.priority());
            if (!t.assignees().isEmpty()) sb.append("  ·  ").append(String.join(", ", t.assignees()));
            if (t.dueDate() != null) sb.append("  ·  límite ").append(Dates.format(t.dueDate()));
            if (t.isComposite()) sb.append("  ·  ").append(Math.round(t.progress() * 100)).append('%');
            setText(sb.toString());
            setFont(getFont().deriveFont(t.isComposite() ? Font.BOLD : Font.PLAIN));
            if (!sel) {
                if (overdue.test(t)) setForeground(new Color(0xB00020));
                else if (t.status() == com.gestor.core.state.TaskStatus.DONE) setForeground(Color.GRAY);
            }
        }
        return this;
    }
}
