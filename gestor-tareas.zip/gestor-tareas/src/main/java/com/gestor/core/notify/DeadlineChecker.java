package com.gestor.core.notify;

import com.gestor.core.model.Project;
import com.gestor.core.model.Task;
import com.gestor.core.state.TaskStatus;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Revisa las fechas límite y publica avisos DUE_SOON / OVERDUE a los responsables.
 * El reloj se inyecta, de modo que las pruebas controlan el tiempo sin esperas reales.
 * Cada aviso se emite una sola vez por tarea y fecha límite.
 */
public class DeadlineChecker {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private final Clock clock;
    private final EventPublisher publisher;
    private final Duration warnBefore;
    private final Set<String> alreadySent = new HashSet<>();

    public DeadlineChecker(Clock clock, EventPublisher publisher, Duration warnBefore) {
        this.clock = clock;
        this.publisher = publisher;
        this.warnBefore = warnBefore;
    }

    public List<TaskEvent> check(Collection<Project> projects) {
        LocalDateTime now = LocalDateTime.now(clock);
        List<TaskEvent> emitted = new ArrayList<>();
        for (Project p : projects) {
            for (Task t : p.allTasks()) {
                if (t.dueDate() == null || t.status() == TaskStatus.DONE) continue;
                EventType type = null;
                if (t.dueDate().isBefore(now)) type = EventType.OVERDUE;
                else if (!t.dueDate().isAfter(now.plus(warnBefore))) type = EventType.DUE_SOON;
                if (type == null) continue;
                if (!alreadySent.add(t.id() + ":" + type + ":" + t.dueDate())) continue;
                String msg = (type == EventType.OVERDUE ? "VENCIDA: " : "Próxima a vencer: ")
                        + "'" + t.title() + "' (proyecto " + p.name() + ") límite " + t.dueDate().format(FMT);
                TaskEvent ev = new TaskEvent(type, t, t.assignees(), msg, now);
                emitted.add(ev);
                publisher.publish(ev);
            }
        }
        return emitted;
    }
}
