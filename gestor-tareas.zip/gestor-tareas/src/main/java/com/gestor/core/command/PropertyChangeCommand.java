package com.gestor.core.command;

import java.util.function.Consumer;

/** Comando genérico para cambiar un atributo simple (título, prioridad, fecha...) guardando el valor previo. */
public class PropertyChangeCommand<T> implements Command {
    private final String description;
    private final T oldValue;
    private final T newValue;
    private final Consumer<T> setter;

    public PropertyChangeCommand(String description, T oldValue, T newValue, Consumer<T> setter) {
        this.description = description;
        this.oldValue = oldValue;
        this.newValue = newValue;
        this.setter = setter;
    }

    @Override public void execute() { setter.accept(newValue); }
    @Override public void undo() { setter.accept(oldValue); }
    @Override public String description() { return description; }
}
