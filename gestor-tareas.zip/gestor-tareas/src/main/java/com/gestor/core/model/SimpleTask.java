package com.gestor.core.model;

import com.gestor.core.state.TaskStatus;
import com.gestor.core.util.IdGenerator;

/** Hoja del Composite: una tarea sin subtareas. */
public class SimpleTask extends Task {
    public SimpleTask(int id, String title) {
        super(id, title);
    }

    @Override public boolean isComposite() { return false; }

    @Override public double progress() { return status() == TaskStatus.DONE ? 1.0 : 0.0; }

    @Override
    public Task deepCopy(IdGenerator ids) {
        SimpleTask copy = new SimpleTask(ids.next(), title());
        copyAttributesTo(copy);
        return copy;
    }
}
