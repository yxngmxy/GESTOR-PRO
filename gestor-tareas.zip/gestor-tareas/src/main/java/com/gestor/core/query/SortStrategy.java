package com.gestor.core.query;

import com.gestor.core.model.Task;

import java.util.Comparator;

/** Rol Strategy: un criterio de ordenamiento intercambiable. */
public interface SortStrategy extends Comparator<Task> {
    String name();
}
