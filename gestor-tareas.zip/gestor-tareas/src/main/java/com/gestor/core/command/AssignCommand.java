package com.gestor.core.command;

import com.gestor.core.model.Task;
import com.gestor.core.notify.EventPublisher;
import com.gestor.core.notify.EventType;

import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;

/** Reemplaza los responsables de una tarea y avisa solo a quienes se acaban de incorporar. */
public class AssignCommand implements Command {
    private final Task task;
    private final Set<String> newAssignees;
    private final EventPublisher events;
    private Set<String> oldAssignees;

    public AssignCommand(Task task, Collection<String> newAssignees, EventPublisher events) {
        this.task = task;
        this.newAssignees = new LinkedHashSet<>(newAssignees);
        this.events = events;
    }

    @Override
    public void execute() {
        oldAssignees = new LinkedHashSet<>(task.assignees());
        task.setAssignees(newAssignees);
        Set<String> added = new LinkedHashSet<>(task.assignees());
        added.removeAll(oldAssignees);
        if (!added.isEmpty())
            events.emit(EventType.ASSIGNED, task, added, "Se te asignó la tarea '" + task.title() + "'");
    }

    @Override public void undo() { task.setAssignees(oldAssignees); }
    @Override public String description() { return "Asignar '" + task.title() + "' a " + newAssignees; }
}
