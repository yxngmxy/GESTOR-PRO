package com.gestor.core.util;

import java.text.Normalizer;
import java.util.Locale;

/** Utilidades de texto compartidas (normalización para comparar entradas del usuario). */
public final class Texts {
    private Texts() {}

    /** Minúsculas, sin tildes y sin espacios/guiones/guiones bajos: "En revisión" -> "enrevision". */
    public static String normalize(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        return n.toLowerCase(Locale.ROOT).replaceAll("[\\s_\\-]", "");
    }
}
