package com.gestor.core.model;

import com.gestor.core.state.StateContext;
import com.gestor.core.state.TaskState;
import com.gestor.core.state.TaskStatus;
import com.gestor.core.util.IdGenerator;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.function.Consumer;

/**
 * Componente del patrón Composite (y "prototipo" del patrón Prototype).
 * Es también el contexto del patrón State: delega las transiciones en {@link TaskState}.
 */
public abstract class Task implements StateContext {
    private final int id;
    private String title;
    private String description = "";
    private Priority priority = Priority.MEDIUM;
    private LocalDateTime dueDate;
    private final Set<String> assignees = new LinkedHashSet<>();
    private TaskState state = TaskState.of(TaskStatus.PENDING);
    CompositeTask parent;

    protected Task(int id, String title) {
        this.id = id;
        setTitle(title);
    }

    // ---------- atributos ----------
    public int id() { return id; }
    public String title() { return title; }
    public String description() { return description; }
    public Priority priority() { return priority; }
    public LocalDateTime dueDate() { return dueDate; }
    public Set<String> assignees() { return Collections.unmodifiableSet(assignees); }
    public CompositeTask parent() { return parent; }

    public void setTitle(String title) {
        if (title == null || title.isBlank()) throw new IllegalArgumentException("El título no puede estar vacío.");
        this.title = title.trim();
    }

    public void setDescription(String description) { this.description = description == null ? "" : description; }
    public void setPriority(Priority priority) { this.priority = priority == null ? Priority.MEDIUM : priority; }
    public void setDueDate(LocalDateTime dueDate) { this.dueDate = dueDate; }

    public void setAssignees(Collection<String> names) {
        assignees.clear();
        if (names != null) names.stream().map(String::trim).filter(s -> !s.isEmpty()).forEach(assignees::add);
    }

    // ---------- estado (delegado en State) ----------
    public TaskStatus status() { return state.status(); }
    public TaskState state() { return state; }

    /** Cambia de estado respetando las reglas; lanza InvalidTransitionException si no se permite. */
    public void moveTo(TaskStatus target) {
        this.state = state.transitionTo(target, this);
    }

    /** Restaura un estado sin validar. Solo para deshacer comandos. */
    public void restoreStatus(TaskStatus status) {
        this.state = TaskState.of(status);
    }

    @Override
    public String describe() { return "la tarea #" + id + " '" + title + "'"; }

    // ---------- Composite ----------
    public abstract boolean isComposite();
    public abstract double progress();
    public abstract Task deepCopy(IdGenerator ids);

    public List<Task> children() { return List.of(); }

    @Override
    public boolean allChildrenDone() { return true; }

    /** Recorre esta tarea y todas sus descendientes en preorden. */
    public void walk(Consumer<Task> visitor) {
        visitor.accept(this);
        for (Task c : children()) c.walk(visitor);
    }

    public List<Task> flatten() {
        List<Task> all = new ArrayList<>();
        walk(all::add);
        return all;
    }

    public Optional<Task> find(int taskId) {
        return flatten().stream().filter(t -> t.id == taskId).findFirst();
    }

    /** Desplaza todas las fechas límite (esta tarea y descendientes). Útil al instanciar plantillas. */
    public void shiftDueDates(Duration delta) {
        walk(t -> { if (t.dueDate != null) t.dueDate = t.dueDate.plus(delta); });
    }

    /** Copia los atributos (no el estado: una copia siempre empieza Pendiente). */
    protected void copyAttributesTo(Task copy) {
        copy.description = description;
        copy.priority = priority;
        copy.dueDate = dueDate;
        copy.assignees.addAll(assignees);
    }

    @Override
    public String toString() {
        return "#" + id + " " + title + " [" + status() + "]";
    }
}
