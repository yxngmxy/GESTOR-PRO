package com.gestor.core.model;

import com.gestor.core.state.TaskStatus;
import com.gestor.core.util.IdGenerator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Nodo compuesto del Composite: una tarea formada por subtareas (simples o compuestas). */
public class CompositeTask extends Task {
    private final List<Task> children = new ArrayList<>();

    public CompositeTask(int id, String title) {
        super(id, title);
    }

    @Override public boolean isComposite() { return true; }

    @Override public List<Task> children() { return Collections.unmodifiableList(children); }

    public int indexOf(Task child) { return children.indexOf(child); }

    public void add(Task child) { add(children.size(), child); }

    public void add(int index, Task child) {
        if (child == null) throw new IllegalArgumentException("La subtarea no puede ser nula.");
        if (child.parent != null) throw new IllegalStateException(child.describe() + " ya pertenece a otra tarea.");
        if (child == this || child.find(id()).isPresent())
            throw new IllegalArgumentException("Una tarea no puede contenerse a sí misma.");
        children.add(index, child);
        child.parent = this;
    }

    public void remove(Task child) {
        if (children.remove(child)) child.parent = null;
    }

    @Override
    public boolean allChildrenDone() {
        return children.stream().allMatch(c -> c.status() == TaskStatus.DONE);
    }

    /** Progreso = promedio del progreso de las subtareas (un compuesto vacío cuenta como una hoja). */
    @Override
    public double progress() {
        if (children.isEmpty()) return status() == TaskStatus.DONE ? 1.0 : 0.0;
        return children.stream().mapToDouble(Task::progress).average().orElse(0);
    }

    @Override
    public Task deepCopy(IdGenerator ids) {
        CompositeTask copy = new CompositeTask(ids.next(), title());
        copyAttributesTo(copy);
        for (Task c : children) copy.add(c.deepCopy(ids));
        return copy;
    }
}
