package com.gestor.core.notify;

import com.gestor.core.model.Task;

import java.time.LocalDateTime;
import java.util.Set;

/** Evento inmutable que se publica a los observadores. {@code recipients} son los responsables a avisar. */
public record TaskEvent(EventType type, Task task, Set<String> recipients, String message, LocalDateTime at) {
    public TaskEvent {
        recipients = Set.copyOf(recipients);
    }
}
