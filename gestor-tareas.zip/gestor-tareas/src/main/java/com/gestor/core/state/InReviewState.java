package com.gestor.core.state;

/** En revisión: se aprueba (terminada) o se devuelve a en curso. Para terminar, las subtareas deben estar terminadas. */
public final class InReviewState extends TaskState {
    public static final InReviewState INSTANCE = new InReviewState();

    private InReviewState() {
        super(TaskStatus.IN_REVIEW, TaskStatus.DONE, TaskStatus.IN_PROGRESS);
    }

    @Override
    protected void guard(TaskStatus target, StateContext ctx) {
        if (target == TaskStatus.DONE && !ctx.allChildrenDone()) {
            throw new InvalidTransitionException(
                    "No se puede terminar " + ctx.describe() + ": tiene subtareas sin terminar.");
        }
    }
}
