package com.gestor.core.model;

import com.gestor.core.util.Texts;

/** Prioridad de una tarea; el orden del enum va de menor a mayor. */
public enum Priority {
    LOW("Baja"),
    MEDIUM("Media"),
    HIGH("Alta"),
    URGENT("Urgente");

    private final String label;

    Priority(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** Acepta etiqueta en español o nombre del enum. */
    public static Priority parse(String text) {
        String n = Texts.normalize(text);
        for (Priority p : values()) {
            if (Texts.normalize(p.label).equals(n) || Texts.normalize(p.name()).equals(n)) return p;
        }
        throw new IllegalArgumentException("Prioridad desconocida: " + text);
    }

    @Override
    public String toString() {
        return label;
    }
}
