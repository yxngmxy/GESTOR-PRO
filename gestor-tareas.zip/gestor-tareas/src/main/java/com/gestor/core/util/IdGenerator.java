package com.gestor.core.util;

import java.util.concurrent.atomic.AtomicInteger;

/** Generador de identificadores enteros consecutivos (fáciles de teclear en la consola). */
public class IdGenerator {
    private final AtomicInteger counter = new AtomicInteger(0);

    public int next() {
        return counter.incrementAndGet();
    }
}
