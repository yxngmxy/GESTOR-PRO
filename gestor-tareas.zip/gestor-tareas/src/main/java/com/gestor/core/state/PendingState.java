package com.gestor.core.state;

/** Pendiente: solo se puede empezar a trabajar. */
public final class PendingState extends TaskState {
    public static final PendingState INSTANCE = new PendingState();

    private PendingState() {
        super(TaskStatus.PENDING, TaskStatus.IN_PROGRESS);
    }
}
