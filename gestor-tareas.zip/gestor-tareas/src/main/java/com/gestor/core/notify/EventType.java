package com.gestor.core.notify;

public enum EventType {
    TASK_CREATED, TASK_REMOVED, STATUS_CHANGED, ASSIGNED, DUE_SOON, OVERDUE
}
