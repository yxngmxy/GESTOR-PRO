package com.gestor.core.notify;

import com.gestor.core.model.Task;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Rol Subject del Observer: mantiene la lista de suscriptores y les reparte los eventos. */
public class EventPublisher {
    private final List<TaskListener> listeners = new CopyOnWriteArrayList<>();
    private final Clock clock;

    public EventPublisher(Clock clock) { this.clock = clock; }

    public void subscribe(TaskListener l) { listeners.add(l); }

    public void unsubscribe(TaskListener l) { listeners.remove(l); }

    /** Atajo para crear y publicar un evento con la hora del reloj inyectado. */
    public void emit(EventType type, Task task, Collection<String> recipients, String message) {
        publish(new TaskEvent(type, task, java.util.Set.copyOf(recipients), message, LocalDateTime.now(clock)));
    }

    public void publish(TaskEvent event) {
        for (TaskListener l : listeners) {
            try {
                l.onEvent(event);
            } catch (RuntimeException ex) {
                // un observador defectuoso no debe romper a los demás ni la operación del usuario
                System.err.println("Observador fallo: " + ex.getMessage());
            }
        }
    }
}
