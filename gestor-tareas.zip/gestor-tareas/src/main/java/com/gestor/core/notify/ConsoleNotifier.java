package com.gestor.core.notify;

import java.io.PrintStream;

/** Observador concreto: imprime en un PrintStream los eventos dirigidos a algún responsable. */
public class ConsoleNotifier implements TaskListener {
    private final PrintStream out;

    public ConsoleNotifier(PrintStream out) { this.out = out; }

    @Override
    public void onEvent(TaskEvent e) {
        if (e.recipients().isEmpty()) return;
        out.println("  >> [" + e.type() + "] para " + String.join(", ", e.recipients()) + ": " + e.message());
    }
}
