package com.gestor.core.state;

/** Terminada: solo se puede reabrir (pasa a en curso). */
public final class DoneState extends TaskState {
    public static final DoneState INSTANCE = new DoneState();

    private DoneState() {
        super(TaskStatus.DONE, TaskStatus.IN_PROGRESS);
    }
}
