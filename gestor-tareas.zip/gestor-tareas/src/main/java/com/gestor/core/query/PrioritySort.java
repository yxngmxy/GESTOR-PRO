package com.gestor.core.query;

import com.gestor.core.model.Task;

/** Más prioritarias primero. */
public class PrioritySort implements SortStrategy {
    @Override public int compare(Task a, Task b) { return b.priority().compareTo(a.priority()); }
    @Override public String name() { return "prioridad"; }
}
