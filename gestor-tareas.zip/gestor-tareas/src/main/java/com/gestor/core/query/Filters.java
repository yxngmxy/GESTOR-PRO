package com.gestor.core.query;

import com.gestor.core.model.Priority;
import com.gestor.core.model.Task;
import com.gestor.core.state.TaskStatus;
import com.gestor.core.util.Texts;

import java.time.Clock;
import java.time.LocalDateTime;
import java.util.function.Predicate;

/** Filtros listos para usar; se combinan con and/or/negate de {@link Predicate}. */
public final class Filters {
    private Filters() {}

    public static Predicate<Task> status(TaskStatus s) { return t -> t.status() == s; }

    public static Predicate<Task> minPriority(Priority p) { return t -> t.priority().compareTo(p) >= 0; }

    public static Predicate<Task> assignee(String name) {
        String n = Texts.normalize(name);
        return t -> t.assignees().stream().anyMatch(a -> Texts.normalize(a).equals(n));
    }

    public static Predicate<Task> overdue(Clock clock) {
        return t -> t.status() != TaskStatus.DONE && t.dueDate() != null
                && t.dueDate().isBefore(LocalDateTime.now(clock));
    }

    public static Predicate<Task> titleContains(String text) {
        String n = Texts.normalize(text);
        return t -> Texts.normalize(t.title()).contains(n);
    }
}
