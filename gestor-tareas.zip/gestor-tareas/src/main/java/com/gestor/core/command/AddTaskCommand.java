package com.gestor.core.command;

import com.gestor.core.model.CompositeTask;
import com.gestor.core.model.Task;
import com.gestor.core.notify.EventPublisher;
import com.gestor.core.notify.EventType;

public class AddTaskCommand implements Command {
    private final CompositeTask parent;
    private final Task task;
    private final EventPublisher events;

    public AddTaskCommand(CompositeTask parent, Task task, EventPublisher events) {
        this.parent = parent;
        this.task = task;
        this.events = events;
    }

    @Override
    public void execute() {
        parent.add(task);
        events.emit(EventType.TASK_CREATED, task, task.assignees(), "Nueva tarea asignada: '" + task.title() + "'");
    }

    @Override public void undo() { parent.remove(task); }
    @Override public String description() { return "Crear tarea '" + task.title() + "'"; }
}
