package com.gestor.core.service;

import com.gestor.core.model.Priority;
import com.gestor.core.model.Project;
import com.gestor.core.model.Task;

import java.time.LocalDateTime;
import java.util.List;

/** Datos de ejemplo para probar rápidamente (opción --demo en consola y GUI). */
public final class DemoData {
    private DemoData() {}

    public static void load(TaskManager tm) {
        LocalDateTime now = LocalDateTime.now(tm.clock());
        Project p = tm.createProject("Lanzamiento web");

        Task design = tm.addTask(p, null, "Diseño", true);
        tm.setPriority(design, Priority.HIGH);
        Task mock = tm.addTask(p, design, "Maquetas", false);
        tm.assign(mock, List.of("Ana"));
        tm.setDueDate(mock, now.plusHours(10));
        Task logo = tm.addTask(p, design, "Logo", false);
        tm.assign(logo, List.of("Luis", "Ana"));
        tm.setDueDate(logo, now.plusDays(3));

        Task dev = tm.addTask(p, null, "Desarrollo", true);
        tm.setPriority(dev, Priority.URGENT);
        Task api = tm.addTask(p, dev, "API REST", false);
        tm.assign(api, List.of("Marta"));
        tm.setDueDate(api, now.minusDays(1));
        tm.setPriority(api, Priority.URGENT);
        Task front = tm.addTask(p, dev, "Interfaz", false);
        tm.assign(front, List.of("Luis"));
        tm.setDueDate(front, now.plusDays(7));

        Task docs = tm.addTask(p, null, "Escribir documentación", false);
        tm.setPriority(docs, Priority.LOW);
        tm.assign(docs, List.of("Marta"));

        tm.history().clear(); // los datos de ejemplo no deben poder deshacerse
    }
}
