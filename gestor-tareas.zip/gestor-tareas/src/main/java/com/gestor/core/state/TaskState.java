package com.gestor.core.state;

import java.util.Arrays;
import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

/**
 * Patrón State: cada estado concreto conoce a qué estados puede pasar y qué condiciones
 * adicionales exige. La tarea delega en su estado actual y no contiene ningún if/switch de reglas.
 */
public abstract class TaskState {
    private final TaskStatus status;
    private final Set<TaskStatus> allowed;

    protected TaskState(TaskStatus status, TaskStatus... allowed) {
        this.status = status;
        this.allowed = allowed.length == 0
                ? Collections.emptySet()
                : Collections.unmodifiableSet(EnumSet.copyOf(Arrays.asList(allowed)));
    }

    public TaskStatus status() {
        return status;
    }

    public Set<TaskStatus> allowedTransitions() {
        return allowed;
    }

    /** Devuelve el nuevo estado o lanza {@link InvalidTransitionException}. */
    public final TaskState transitionTo(TaskStatus target, StateContext ctx) {
        if (target == status) {
            throw new InvalidTransitionException(ctx.describe() + " ya está en estado '" + status + "'.");
        }
        if (!allowed.contains(target)) {
            throw new InvalidTransitionException("Transición no permitida para " + ctx.describe() + ": '"
                    + status + "' -> '" + target + "'. Permitidas: " + allowed + ".");
        }
        guard(target, ctx);
        return of(target);
    }

    /** Gancho para reglas adicionales de cada estado (por defecto no exige nada). */
    protected void guard(TaskStatus target, StateContext ctx) {}

    /** Obtiene la instancia (singleton, sin estado propio) que corresponde a un {@link TaskStatus}. */
    public static TaskState of(TaskStatus s) {
        switch (s) {
            case PENDING: return PendingState.INSTANCE;
            case IN_PROGRESS: return InProgressState.INSTANCE;
            case IN_REVIEW: return InReviewState.INSTANCE;
            case DONE: return DoneState.INSTANCE;
            default: throw new AssertionError(s);
        }
    }

    @Override
    public String toString() {
        return status.label();
    }
}
