package com.gestor.core.query;

import com.gestor.core.model.Task;

import java.util.Comparator;

/** Por responsable (alfabético, según el primero de la lista); las tareas sin responsable van al final. */
public class AssigneeSort implements SortStrategy {
    private static String first(Task t) {
        return t.assignees().stream().findFirst().map(String::toLowerCase).orElse(null);
    }

    private static final Comparator<Task> CMP =
            Comparator.comparing(AssigneeSort::first, Comparator.nullsLast(Comparator.naturalOrder()));

    @Override public int compare(Task a, Task b) { return CMP.compare(a, b); }
    @Override public String name() { return "responsable"; }
}
