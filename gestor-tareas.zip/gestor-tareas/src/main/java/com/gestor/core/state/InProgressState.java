package com.gestor.core.state;

/** En curso: se puede enviar a revisión o devolver a pendiente. */
public final class InProgressState extends TaskState {
    public static final InProgressState INSTANCE = new InProgressState();

    private InProgressState() {
        super(TaskStatus.IN_PROGRESS, TaskStatus.IN_REVIEW, TaskStatus.PENDING);
    }
}
