package com.gestor.core.util;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/** Lectura/escritura de fechas límite en un formato único para consola y GUI. */
public final class Dates {
    public static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private Dates() {}

    /**
     * Acepta "yyyy-MM-dd" (se toma 23:59), "yyyy-MM-dd HH:mm" o "yyyy-MM-ddTHH:mm".
     * Texto vacío o "ninguna" devuelve null (sin fecha).
     */
    public static LocalDateTime parse(String text) {
        if (text == null) return null;
        String s = text.trim();
        if (s.isEmpty() || Texts.normalize(s).equals("ninguna") || Texts.normalize(s).equals("ninguno")) return null;
        try {
            if (s.length() == 10) return LocalDate.parse(s).atTime(23, 59);
            return LocalDateTime.parse(s.replace(' ', 'T'));
        } catch (DateTimeParseException e) {
            throw new IllegalArgumentException("Fecha inválida '" + text + "'. Use yyyy-MM-dd o yyyy-MM-dd HH:mm.");
        }
    }

    public static String format(LocalDateTime d) {
        return d == null ? "sin fecha" : d.format(FORMAT);
    }
}
