package com.gestor.core.state;

/**
 * Lo mínimo que un estado necesita saber de la tarea a la que pertenece.
 * Así el paquete {@code state} no depende del paquete {@code model} (DIP).
 */
public interface StateContext {
    String describe();

    boolean allChildrenDone();
}
