package com.gestor.core.command;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Optional;

/** Invoker del patrón Command: gestiona las pilas de deshacer y rehacer. */
public class CommandHistory {
    private final Deque<Command> undoStack = new ArrayDeque<>();
    private final Deque<Command> redoStack = new ArrayDeque<>();

    /** Ejecuta y registra. Si execute() falla, el comando no entra al historial. */
    public void execute(Command c) {
        c.execute();
        undoStack.push(c);
        redoStack.clear();
    }

    public Optional<String> undo() {
        if (undoStack.isEmpty()) return Optional.empty();
        Command c = undoStack.pop();
        c.undo();
        redoStack.push(c);
        return Optional.of(c.description());
    }

    public Optional<String> redo() {
        if (redoStack.isEmpty()) return Optional.empty();
        Command c = redoStack.pop();
        c.execute();
        undoStack.push(c);
        return Optional.of(c.description());
    }

    public boolean canUndo() { return !undoStack.isEmpty(); }
    public boolean canRedo() { return !redoStack.isEmpty(); }
    public Optional<String> nextUndo() { return Optional.ofNullable(undoStack.peek()).map(Command::description); }
    public Optional<String> nextRedo() { return Optional.ofNullable(redoStack.peek()).map(Command::description); }
    public void clear() { undoStack.clear(); redoStack.clear(); }
    public int undoSize() { return undoStack.size(); }
}
