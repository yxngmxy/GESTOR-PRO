package com.gestor.core.query;

import com.gestor.core.util.Texts;

import java.util.List;

/** Catálogo de estrategias disponibles, para elegirlas por nombre desde la consola o la GUI. */
public final class SortStrategies {
    private SortStrategies() {}

    public static List<SortStrategy> all() {
        return List.of(new NoSort(), new PrioritySort(), new DueDateSort(), new AssigneeSort());
    }

    public static SortStrategy byName(String name) {
        String n = Texts.normalize(name);
        for (SortStrategy s : all()) if (Texts.normalize(s.name()).equals(n)) return s;
        if (n.equals("priority")) return new PrioritySort();
        if (n.equals("date") || n.equals("duedate")) return new DueDateSort();
        if (n.equals("assignee")) return new AssigneeSort();
        throw new IllegalArgumentException("Criterio de orden desconocido: " + name + " (use prioridad, fecha, responsable o ninguno)");
    }
}
