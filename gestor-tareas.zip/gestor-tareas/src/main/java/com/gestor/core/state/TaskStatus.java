package com.gestor.core.state;

import com.gestor.core.util.Texts;

/** Identificador "plano" de cada estado; útil para filtrar y mostrar. */
public enum TaskStatus {
    PENDING("Pendiente"),
    IN_PROGRESS("En curso"),
    IN_REVIEW("En revisión"),
    DONE("Terminada");

    private final String label;

    TaskStatus(String label) {
        this.label = label;
    }

    public String label() {
        return label;
    }

    /** Acepta etiqueta en español o nombre del enum ("en curso", "IN_PROGRESS", "revision"...). */
    public static TaskStatus parse(String text) {
        String n = Texts.normalize(text);
        for (TaskStatus s : values()) {
            if (Texts.normalize(s.label).equals(n) || Texts.normalize(s.name()).equals(n)) return s;
        }
        switch (n) {
            case "revision": return IN_REVIEW;
            case "curso": return IN_PROGRESS;
            case "hecha": case "completada": case "terminado": return DONE;
            default: throw new IllegalArgumentException("Estado desconocido: " + text);
        }
    }

    @Override
    public String toString() {
        return label;
    }
}
