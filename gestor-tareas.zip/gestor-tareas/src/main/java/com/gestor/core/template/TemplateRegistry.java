package com.gestor.core.template;

import com.gestor.core.model.Project;
import com.gestor.core.model.Task;
import com.gestor.core.util.IdGenerator;
import com.gestor.core.util.Texts;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Registro de prototipos (patrón Prototype). Guarda copias profundas de tareas o proyectos
 * y entrega nuevas copias independientes, con ids nuevos y en estado Pendiente.
 */
public class TemplateRegistry {
    private final IdGenerator ids;
    private final IdGenerator projectIds;
    private final Map<String, Task> taskTemplates = new LinkedHashMap<>();
    private final Map<String, Project> projectTemplates = new LinkedHashMap<>();

    public TemplateRegistry(IdGenerator ids, IdGenerator projectIds) {
        this.ids = ids;
        this.projectIds = projectIds;
    }

    // ---- tareas ----
    public void saveTask(String name, Task source) {
        taskTemplates.put(key(name), source.deepCopy(ids));
    }

    /** @param newDue si no es null y la plantilla tiene fecha, todas las fechas se desplazan en bloque. */
    public Task instantiateTask(String name, LocalDateTime newDue) {
        Task proto = taskTemplates.get(key(name));
        if (proto == null) throw new IllegalArgumentException("No existe la plantilla de tarea '" + name + "'.");
        Task copy = proto.deepCopy(ids);
        if (newDue != null && proto.dueDate() != null) copy.shiftDueDates(Duration.between(proto.dueDate(), newDue));
        return copy;
    }

    // ---- proyectos ----
    public void saveProject(String name, Project source) {
        projectTemplates.put(key(name), source.deepCopy(ids, 0, source.name()));
    }

    /** @param start si no es null, se desplazan las fechas para que la más temprana coincida con start. */
    public Project instantiateProject(String templateName, String newProjectName, LocalDateTime start) {
        Project proto = projectTemplates.get(key(templateName));
        if (proto == null) throw new IllegalArgumentException("No existe la plantilla de proyecto '" + templateName + "'.");
        Project copy = proto.deepCopy(ids, projectIds.next(), newProjectName);
        if (start != null) {
            proto.earliestDue().ifPresent(first -> copy.root().shiftDueDates(Duration.between(first, start)));
        }
        return copy;
    }

    public List<String> taskTemplateNames() { return new ArrayList<>(taskTemplates.keySet()); }
    public List<String> projectTemplateNames() { return new ArrayList<>(projectTemplates.keySet()); }

    private static String key(String name) { return Texts.normalize(name); }
}
