package com.gestor.core.service;

import com.gestor.core.command.AddProjectCommand;
import com.gestor.core.command.AddTaskCommand;
import com.gestor.core.command.AssignCommand;
import com.gestor.core.command.ChangeStatusCommand;
import com.gestor.core.command.Command;
import com.gestor.core.command.CommandHistory;
import com.gestor.core.command.PropertyChangeCommand;
import com.gestor.core.command.RemoveTaskCommand;
import com.gestor.core.model.CompositeTask;
import com.gestor.core.model.Priority;
import com.gestor.core.model.Project;
import com.gestor.core.model.SimpleTask;
import com.gestor.core.model.Task;
import com.gestor.core.notify.DeadlineChecker;
import com.gestor.core.notify.EventPublisher;
import com.gestor.core.notify.TaskEvent;
import com.gestor.core.notify.UserInbox;
import com.gestor.core.state.TaskStatus;
import com.gestor.core.template.TemplateRegistry;
import com.gestor.core.util.IdGenerator;
import com.gestor.core.util.Texts;

import java.time.Clock;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

/**
 * Fachada del núcleo: único punto de entrada para la consola y la GUI.
 * Toda operación que modifica datos se ejecuta como un Command, por lo que es deshacible.
 */
public class TaskManager {
    private final Clock clock;
    private final IdGenerator ids = new IdGenerator();            // ids de tareas
    private final IdGenerator projectIds = new IdGenerator();     // ids de proyectos
    private final List<Project> projects = new ArrayList<>();
    private final CommandHistory history = new CommandHistory();
    private final EventPublisher events;
    private final TemplateRegistry templates = new TemplateRegistry(ids, projectIds);
    private final DeadlineChecker deadlines;
    private final UserInbox inbox = new UserInbox();

    public TaskManager() { this(Clock.systemDefaultZone()); }

    public TaskManager(Clock clock) {
        this.clock = clock;
        this.events = new EventPublisher(clock);
        this.deadlines = new DeadlineChecker(clock, events, Duration.ofHours(24));
        this.events.subscribe(inbox);
    }

    // ---------- acceso a colaboradores ----------
    public Clock clock() { return clock; }
    public EventPublisher events() { return events; }
    public UserInbox inbox() { return inbox; }
    public CommandHistory history() { return history; }
    public TemplateRegistry templates() { return templates; }
    public List<Project> projects() { return Collections.unmodifiableList(projects); }

    // ---------- proyectos ----------
    public Project createProject(String name) {
        Project p = new Project(projectIds.next(), name, new CompositeTask(0, name));
        history.execute(new AddProjectCommand(projects, p));
        return p;
    }

    public Optional<Project> findProject(String idOrName) {
        String s = idOrName.trim();
        for (Project p : projects) {
            if (s.equals(String.valueOf(p.id())) || Texts.normalize(p.name()).equals(Texts.normalize(s))) return Optional.of(p);
        }
        return Optional.empty();
    }

    public Optional<Task> findTask(int taskId) {
        return projects.stream().map(p -> p.find(taskId)).flatMap(Optional::stream).findFirst();
    }

    public Optional<Project> projectOf(Task task) {
        Task top = task;
        while (top.parent() != null) top = top.parent();
        for (Project p : projects) if (p.root() == top) return Optional.of(p);
        return Optional.empty();
    }

    // ---------- tareas ----------
    /** @param parent tarea compuesta donde colgar la nueva; null = primer nivel del proyecto. */
    public Task addTask(Project project, Task parent, String title, boolean composite) {
        CompositeTask container = project.root();
        if (parent != null) {
            if (!(parent instanceof CompositeTask))
                throw new IllegalArgumentException(parent.describe() + " es simple; solo las tareas compuestas admiten subtareas.");
            container = (CompositeTask) parent;
        }
        Task t = composite ? new CompositeTask(ids.next(), title) : new SimpleTask(ids.next(), title);
        history.execute(new AddTaskCommand(container, t, events));
        return t;
    }

    /** Inserta una copia nueva de una plantilla de tarea. */
    public Task addTaskFromTemplate(Project project, Task parent, String templateName, LocalDateTime newDue) {
        CompositeTask container = parent == null ? project.root() : requireComposite(parent);
        Task t = templates.instantiateTask(templateName, newDue);
        history.execute(new AddTaskCommand(container, t, events));
        return t;
    }

    /** Crea un proyecto nuevo a partir de una plantilla de proyecto. */
    public Project createProjectFromTemplate(String templateName, String newName, LocalDateTime start) {
        Project p = templates.instantiateProject(templateName, newName, start);
        history.execute(new AddProjectCommand(projects, p));
        return p;
    }

    public void remove(Task task) { history.execute(new RemoveTaskCommand(task, events)); }

    public void changeStatus(Task task, TaskStatus target) { history.execute(new ChangeStatusCommand(task, target, events)); }

    public void rename(Task task, String newTitle) {
        run(new PropertyChangeCommand<>("Renombrar '" + task.title() + "'", task.title(), newTitle, task::setTitle));
    }

    public void setDescription(Task task, String text) {
        run(new PropertyChangeCommand<>("Cambiar descripción de '" + task.title() + "'", task.description(), text, task::setDescription));
    }

    public void setPriority(Task task, Priority p) {
        run(new PropertyChangeCommand<>("Prioridad de '" + task.title() + "' a " + p, task.priority(), p, task::setPriority));
    }

    public void setDueDate(Task task, LocalDateTime due) {
        run(new PropertyChangeCommand<>("Fecha límite de '" + task.title() + "'", task.dueDate(), due, task::setDueDate));
    }

    public void assign(Task task, Collection<String> people) { run(new AssignCommand(task, people, events)); }

    // ---------- deshacer / rehacer ----------
    public Optional<String> undo() { return history.undo(); }
    public Optional<String> redo() { return history.redo(); }

    // ---------- alertas ----------
    /** Revisa fechas límite de todos los proyectos y publica los avisos nuevos. */
    public List<TaskEvent> checkDeadlines() { return deadlines.check(projects); }

    // ---------- util ----------
    private void run(Command c) { history.execute(c); }

    private CompositeTask requireComposite(Task t) {
        if (t instanceof CompositeTask) return (CompositeTask) t;
        throw new IllegalArgumentException(t.describe() + " es simple; solo las tareas compuestas admiten subtareas.");
    }
}
