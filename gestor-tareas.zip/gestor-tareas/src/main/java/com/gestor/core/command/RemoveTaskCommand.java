package com.gestor.core.command;

import com.gestor.core.model.CompositeTask;
import com.gestor.core.model.Task;
import com.gestor.core.notify.EventPublisher;
import com.gestor.core.notify.EventType;

/** Elimina una tarea (con sus subtareas) recordando su posición para poder restaurarla igual. */
public class RemoveTaskCommand implements Command {
    private final Task task;
    private final EventPublisher events;
    private CompositeTask parent;
    private int index;

    public RemoveTaskCommand(Task task, EventPublisher events) {
        if (task.parent() == null) throw new IllegalArgumentException("No se puede eliminar la raíz del proyecto.");
        this.task = task;
        this.events = events;
    }

    @Override
    public void execute() {
        parent = task.parent();
        index = parent.indexOf(task);
        parent.remove(task);
        events.emit(EventType.TASK_REMOVED, task, task.assignees(), "Tarea eliminada: '" + task.title() + "'");
    }

    @Override public void undo() { parent.add(index, task); }
    @Override public String description() { return "Eliminar tarea '" + task.title() + "'"; }
}
