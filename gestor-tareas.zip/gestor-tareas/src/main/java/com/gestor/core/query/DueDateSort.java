package com.gestor.core.query;

import com.gestor.core.model.Task;

import java.util.Comparator;

/** Fecha límite más cercana primero; las tareas sin fecha van al final. */
public class DueDateSort implements SortStrategy {
    private static final Comparator<Task> CMP =
            Comparator.comparing(Task::dueDate, Comparator.nullsLast(Comparator.naturalOrder()));

    @Override public int compare(Task a, Task b) { return CMP.compare(a, b); }
    @Override public String name() { return "fecha"; }
}
