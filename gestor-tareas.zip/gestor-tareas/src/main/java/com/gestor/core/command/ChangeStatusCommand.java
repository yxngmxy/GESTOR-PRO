package com.gestor.core.command;

import com.gestor.core.model.Task;
import com.gestor.core.notify.EventPublisher;
import com.gestor.core.notify.EventType;
import com.gestor.core.state.TaskStatus;

public class ChangeStatusCommand implements Command {
    private final Task task;
    private final TaskStatus target;
    private final EventPublisher events;
    private TaskStatus previous;

    public ChangeStatusCommand(Task task, TaskStatus target, EventPublisher events) {
        this.task = task;
        this.target = target;
        this.events = events;
    }

    @Override
    public void execute() {
        previous = task.status();
        task.moveTo(target); // puede lanzar InvalidTransitionException: en ese caso nada cambia
        events.emit(EventType.STATUS_CHANGED, task, task.assignees(),
                "'" + task.title() + "': " + previous + " -> " + target);
    }

    @Override public void undo() { task.restoreStatus(previous); }
    @Override public String description() { return "Cambiar estado de '" + task.title() + "' a " + target; }
}
