package com.gestor.core.notify;

/** Rol Observer. Los canales de aviso (consola, bandeja, GUI...) implementan esta interfaz. */
public interface TaskListener {
    void onEvent(TaskEvent event);
}
