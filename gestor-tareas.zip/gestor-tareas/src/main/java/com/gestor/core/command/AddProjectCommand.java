package com.gestor.core.command;

import com.gestor.core.model.Project;

import java.util.List;

public class AddProjectCommand implements Command {
    private final List<Project> projects;
    private final Project project;

    public AddProjectCommand(List<Project> projects, Project project) {
        this.projects = projects;
        this.project = project;
    }

    @Override public void execute() { projects.add(project); }
    @Override public void undo() { projects.remove(project); }
    @Override public String description() { return "Crear proyecto '" + project.name() + "'"; }
}
