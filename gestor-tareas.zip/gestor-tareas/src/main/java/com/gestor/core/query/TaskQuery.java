package com.gestor.core.query;

import com.gestor.core.model.Task;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/**
 * Consulta inmutable: un filtro + una estrategia de orden. Sirve para listar tareas hermanas
 * conservando la jerarquía: un compuesto se muestra si él o alguna subtarea cumple el filtro.
 */
public class TaskQuery {
    private final Predicate<Task> filter;
    private final SortStrategy sort;
    private final boolean descending;

    private TaskQuery(Predicate<Task> filter, SortStrategy sort, boolean descending) {
        this.filter = filter;
        this.sort = sort;
        this.descending = descending;
    }

    public static TaskQuery all() { return new TaskQuery(t -> true, new NoSort(), false); }

    public TaskQuery where(Predicate<Task> p) { return new TaskQuery(filter.and(p), sort, descending); }
    public TaskQuery sortedBy(SortStrategy s) { return new TaskQuery(filter, s, descending); }
    public TaskQuery reversed() { return new TaskQuery(filter, sort, !descending); }
    public SortStrategy sortStrategy() { return sort; }

    public boolean matchesDeep(Task t) {
        return filter.test(t) || t.children().stream().anyMatch(this::matchesDeep);
    }

    /** Aplica filtro y orden a una lista de hermanas (el orden es estable). */
    public List<Task> select(List<Task> siblings) {
        List<Task> result = new ArrayList<>();
        for (Task t : siblings) if (matchesDeep(t)) result.add(t);
        result.sort(descending ? sort.reversed() : sort);
        return result;
    }

    /** Lista plana de todas las tareas (a cualquier nivel) que cumplen el filtro, ordenadas. */
    public List<Task> flat(List<Task> roots) {
        List<Task> result = new ArrayList<>();
        for (Task r : roots) r.walk(t -> { if (filter.test(t)) result.add(t); });
        result.sort(descending ? sort.reversed() : sort);
        return result;
    }
}
