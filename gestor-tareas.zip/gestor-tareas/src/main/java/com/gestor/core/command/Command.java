package com.gestor.core.command;

/** Rol Command: cada acción del usuario es un objeto que sabe ejecutarse y deshacerse. */
public interface Command {
    void execute();

    void undo();

    String description();
}
