package com.gestor.core.state;

/** Se lanza cuando se intenta una transición de estado que las reglas no permiten. */
public class InvalidTransitionException extends IllegalStateException {
    public InvalidTransitionException(String message) {
        super(message);
    }
}
