package com.gestor.core.model;

import com.gestor.core.util.IdGenerator;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

/** Un proyecto es un nombre más una tarea compuesta "raíz" que agrupa sus tareas. */
public class Project {
    private final int id;
    private String name;
    private final CompositeTask root;

    public Project(int id, String name, CompositeTask root) {
        if (name == null || name.isBlank()) throw new IllegalArgumentException("El proyecto necesita un nombre.");
        this.id = id;
        this.name = name.trim();
        this.root = root;
    }

    public int id() { return id; }
    public String name() { return name; }
    public CompositeTask root() { return root; }

    /** Tareas de primer nivel. */
    public List<Task> tasks() { return root.children(); }

    public Optional<Task> find(int taskId) {
        return root.children().stream().map(t -> t.find(taskId)).flatMap(Optional::stream).findFirst();
    }

    public List<Task> allTasks() {
        List<Task> all = root.flatten();
        all.remove(root);
        return all;
    }

    public double progress() { return root.progress(); }

    public Optional<LocalDateTime> earliestDue() {
        return allTasks().stream().map(Task::dueDate).filter(d -> d != null).min(LocalDateTime::compareTo);
    }

    /** Copia profunda con nuevo nombre e ids de tarea nuevos (Prototype). La raíz interna usa siempre id 0. */
    public Project deepCopy(IdGenerator taskIds, int newProjectId, String newName) {
        CompositeTask newRoot = new CompositeTask(0, newName);
        for (Task c : root.children()) newRoot.add(c.deepCopy(taskIds));
        return new Project(newProjectId, newName, newRoot);
    }

    @Override
    public String toString() { return "Proyecto #" + id + " " + name; }
}
