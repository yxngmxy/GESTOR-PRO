package com.gestor.core.notify;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Observador concreto: guarda los avisos de cada responsable (lo usa la GUI y las pruebas). */
public class UserInbox implements TaskListener {
    private final Map<String, List<String>> messages = new LinkedHashMap<>();
    private final List<String> all = new ArrayList<>();

    @Override
    public synchronized void onEvent(TaskEvent e) {
        for (String user : e.recipients()) {
            messages.computeIfAbsent(user, k -> new ArrayList<>()).add(e.message());
            all.add("[" + e.type() + "] " + user + ": " + e.message());
        }
    }

    public synchronized List<String> messagesFor(String user) {
        return List.copyOf(messages.getOrDefault(user, Collections.emptyList()));
    }

    public synchronized List<String> all() { return List.copyOf(all); }

    public synchronized void clear() { messages.clear(); all.clear(); }
}
