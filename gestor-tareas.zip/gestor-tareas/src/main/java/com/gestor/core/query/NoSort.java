package com.gestor.core.query;

import com.gestor.core.model.Task;

/** Mantiene el orden original (de creación). */
public class NoSort implements SortStrategy {
    @Override public int compare(Task a, Task b) { return 0; }
    @Override public String name() { return "ninguno"; }
}
