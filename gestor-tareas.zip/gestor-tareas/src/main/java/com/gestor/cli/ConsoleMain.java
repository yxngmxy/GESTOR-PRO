package com.gestor.cli;

import com.gestor.core.notify.ConsoleNotifier;
import com.gestor.core.service.DemoData;
import com.gestor.core.service.TaskManager;

import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/** Punto de entrada de la versión por consola. Opción: --demo carga datos de ejemplo. */
public class ConsoleMain {
    public static void main(String[] args) {
        PrintStream out = new PrintStream(System.out, true, StandardCharsets.UTF_8);
        TaskManager tm = new TaskManager();
        tm.events().subscribe(new ConsoleNotifier(out));
        if (Arrays.asList(args).contains("--demo")) DemoData.load(tm);
        new ConsoleApp(tm, System.in, out).run();
    }
}
