package com.gestor.cli;

import com.gestor.core.model.Priority;
import com.gestor.core.model.Project;
import com.gestor.core.model.Task;
import com.gestor.core.notify.TaskEvent;
import com.gestor.core.query.Filters;
import com.gestor.core.query.SortStrategies;
import com.gestor.core.query.TaskQuery;
import com.gestor.core.service.TaskManager;
import com.gestor.core.state.TaskStatus;
import com.gestor.core.util.Dates;
import com.gestor.core.util.Texts;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/** Interfaz de consola. No contiene reglas de negocio: solo interpreta texto y llama a {@link TaskManager}. */
public class ConsoleApp {
    private final TaskManager tm;
    private final BufferedReader in;
    private final PrintStream out;
    private Project current;

    public ConsoleApp(TaskManager tm, InputStream in, PrintStream out) {
        this.tm = tm;
        this.in = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
        this.out = out;
        if (!tm.projects().isEmpty()) current = tm.projects().get(0);
    }

    public void run() {
        out.println("Gestor de tareas y proyectos. Escriba 'ayuda' para ver los comandos.");
        try {
            while (true) {
                out.print("gestor" + (current == null ? "" : "[" + current.name() + "]") + "> ");
                out.flush();
                String line = in.readLine();
                if (line == null || !execute(line)) break;
            }
        } catch (IOException e) {
            out.println("Error de lectura: " + e.getMessage());
        }
        out.println("Hasta luego.");
    }

    /** Ejecuta una línea. Devuelve false si el usuario pidió salir. Los errores de uso se muestran, no se propagan. */
    public boolean execute(String line) {
        List<Token> tokens = tokenize(line);
        if (tokens.isEmpty()) return true;
        String cmd = Texts.normalize(tokens.get(0).text);
        Args a = new Args(tokens.subList(1, tokens.size()));
        try {
            switch (cmd) {
                case "salir": case "exit": case "q": return false;
                case "ayuda": case "help": case "?": help(); break;
                case "proyecto": newProject(a); break;
                case "proyectos": listProjects(); break;
                case "usar": use(a); break;
                case "nueva": case "tarea": newTask(a); break;
                case "listar": case "ls": list(a); break;
                case "ver": show(a); break;
                case "estado": status(a); break;
                case "prioridad": priority(a); break;
                case "fecha": due(a); break;
                case "resp": case "responsables": assign(a); break;
                case "renombrar": rename(a); break;
                case "eliminar": remove(a); break;
                case "deshacer": case "undo": undo(); break;
                case "rehacer": case "redo": redo(); break;
                case "alertas": alerts(); break;
                case "bandeja": inbox(a); break;
                case "plantilla": template(a); break;
                case "plantillas": listTemplates(); break;
                default: out.println("Comando desconocido: '" + tokens.get(0).text + "'. Escriba 'ayuda'.");
            }
        } catch (IllegalArgumentException | IllegalStateException | UnsupportedOperationException ex) {
            out.println("Error: " + ex.getMessage());
        }
        return true;
    }

    // ------------------------------------------------------------------ comandos
    private void help() {
        out.println(String.join("\n",
                "Proyectos:",
                "  proyecto <nombre>              crea un proyecto y lo selecciona",
                "  proyectos | usar <id|nombre>   lista / cambia de proyecto",
                "Tareas:",
                "  nueva <título> [grupo] [en=ID] [prioridad=ALTA] [fecha=2026-12-31] [resp=ana,luis]",
                "      'grupo' crea una tarea compuesta (admite subtareas con en=ID)",
                "  listar [orden=prioridad|fecha|responsable] [desc] [estado=..] [resp=..] [prioridad=..]",
                "         [vencidas] [texto=..] [plano]      (la prioridad filtra \"esa o mayor\")",
                "  ver <id> | estado <id> <estado> | prioridad <id> <p> | fecha <id> <f|ninguna>",
                "  resp <id> <a,b> | renombrar <id> <título> | eliminar <id>",
                "  Estados: pendiente, en curso, en revisión, terminada",
                "Historial:  deshacer | rehacer",
                "Alertas:    alertas | bandeja [usuario]",
                "Plantillas: plantilla guardar <nombre> <idTarea> | plantilla guardar-proyecto <nombre>",
                "            plantilla usar <nombre> [en=ID] [fecha=..] | plantilla usar-proyecto <plantilla> <nuevo> [fecha=..]",
                "            plantillas",
                "Otros:      ayuda | salir"));
    }

    private void newProject(Args a) {
        current = tm.createProject(a.joined(0));
        out.println("Creado " + current + " (seleccionado).");
    }

    private void listProjects() {
        if (tm.projects().isEmpty()) { out.println("No hay proyectos."); return; }
        for (Project p : tm.projects())
            out.printf("%s #%d %s  (%.0f%% completo)%n", p == current ? "*" : " ", p.id(), p.name(), p.progress() * 100);
    }

    private void use(Args a) {
        current = tm.findProject(a.joined(0)).orElseThrow(() -> new IllegalArgumentException("Proyecto no encontrado."));
        out.println("Proyecto actual: " + current.name());
    }

    private void newTask(Args a) {
        Project p = requireProject();
        List<String> words = new ArrayList<>(a.positional);
        boolean group = words.removeIf(w -> Texts.normalize(w).equals("grupo") || Texts.normalize(w).equals("compuesta"));
        Task parent = a.has("en") ? taskInProject(Integer.parseInt(a.opt("en"))) : null;
        Task t = tm.addTask(p, parent, String.join(" ", words), group);
        if (a.has("prioridad")) tm.setPriority(t, Priority.parse(a.opt("prioridad")));
        if (a.has("fecha")) tm.setDueDate(t, Dates.parse(a.opt("fecha")));
        if (a.has("resp")) tm.assign(t, splitNames(a.opt("resp")));
        out.println("Creada " + t + (t.isComposite() ? " (compuesta)" : ""));
    }

    private void list(Args a) {
        Project p = requireProject();
        TaskQuery q = TaskQuery.all();
        if (a.has("estado")) q = q.where(Filters.status(TaskStatus.parse(a.opt("estado"))));
        if (a.has("resp")) q = q.where(Filters.assignee(a.opt("resp")));
        if (a.has("prioridad")) q = q.where(Filters.minPriority(Priority.parse(a.opt("prioridad"))));
        if (a.has("texto")) q = q.where(Filters.titleContains(a.opt("texto")));
        if (a.flag("vencidas")) q = q.where(Filters.overdue(tm.clock()));
        if (a.has("orden")) q = q.sortedBy(SortStrategies.byName(a.opt("orden")));
        if (a.flag("desc")) q = q.reversed();

        out.println(p.name() + "  (" + Math.round(p.progress() * 100) + "% completo)");
        List<Task> shown = a.flag("plano") ? q.flat(p.tasks()) : q.select(p.tasks());
        if (shown.isEmpty()) { out.println("  (sin tareas que coincidan)"); return; }
        if (a.flag("plano")) shown.forEach(t -> out.println("  " + line(t)));
        else printTree(shown, q, "  ");
    }

    private void printTree(List<Task> nodes, TaskQuery q, String indent) {
        for (Task t : nodes) {
            out.println(indent + line(t));
            printTree(q.select(t.children()), q, indent + "    ");
        }
    }

    private String line(Task t) {
        StringBuilder sb = new StringBuilder();
        sb.append(t.isComposite() ? "▸ " : "  ").append('#').append(t.id()).append(" [").append(t.status()).append("] ")
          .append(t.title()).append("  · ").append(t.priority());
        if (!t.assignees().isEmpty()) sb.append(" · ").append(String.join(", ", t.assignees()));
        if (t.dueDate() != null) sb.append(" · límite ").append(Dates.format(t.dueDate()));
        if (t.isComposite()) sb.append(" · ").append(Math.round(t.progress() * 100)).append('%');
        return sb.toString();
    }

    private void show(Args a) {
        Task t = taskInProject(a.id(0));
        out.println(line(t).trim());
        out.println("  Descripción: " + (t.description().isEmpty() ? "-" : t.description()));
        out.println("  Estados permitidos desde aquí: " + t.state().allowedTransitions());
        if (t.parent() != null && t.parent().parent() != null) out.println("  Subtarea de: " + t.parent());
    }

    private void status(Args a) {
        Task t = taskInProject(a.id(0));
        tm.changeStatus(t, TaskStatus.parse(a.joined(1)));
        out.println("OK: " + t);
    }

    private void priority(Args a) {
        Task t = taskInProject(a.id(0));
        tm.setPriority(t, Priority.parse(a.joined(1)));
        out.println("OK: " + t + " prioridad " + t.priority());
    }

    private void due(Args a) {
        Task t = taskInProject(a.id(0));
        tm.setDueDate(t, Dates.parse(a.joined(1)));
        out.println("OK: " + t + " límite " + Dates.format(t.dueDate()));
    }

    private void assign(Args a) {
        Task t = taskInProject(a.id(0));
        tm.assign(t, splitNames(a.joined(1)));
        out.println("OK: " + t + " responsables " + t.assignees());
    }

    private void rename(Args a) {
        Task t = taskInProject(a.id(0));
        tm.rename(t, a.joined(1));
        out.println("OK: " + t);
    }

    private void remove(Args a) {
        Task t = taskInProject(a.id(0));
        tm.remove(t);
        out.println("Eliminada " + t + " (use 'deshacer' para recuperarla).");
    }

    private void undo() {
        out.println(tm.undo().map(d -> "Deshecho: " + d).orElse("No hay nada que deshacer."));
    }

    private void redo() {
        out.println(tm.redo().map(d -> "Rehecho: " + d).orElse("No hay nada que rehacer."));
    }

    private void alerts() {
        List<TaskEvent> sent = tm.checkDeadlines(); // los observadores (consola, bandeja) ya los muestran
        if (sent.isEmpty()) out.println("Sin alertas nuevas.");
    }

    private void inbox(Args a) {
        List<String> msgs = a.positional.isEmpty() ? tm.inbox().all() : tm.inbox().messagesFor(a.joined(0));
        if (msgs.isEmpty()) out.println("Bandeja vacía.");
        else msgs.forEach(m -> out.println("  - " + m));
    }

    private void template(Args a) {
        if (a.positional.isEmpty()) throw new IllegalArgumentException("Use: plantilla guardar|guardar-proyecto|usar|usar-proyecto ...");
        String sub = Texts.normalize(a.positional.get(0));
        Args r = a.drop(1);
        switch (sub) {
            case "guardar": {
                Task t = taskInProject(Integer.parseInt(r.positional.get(1)));
                tm.templates().saveTask(r.positional.get(0), t);
                out.println("Plantilla de tarea '" + r.positional.get(0) + "' guardada.");
                break;
            }
            case "guardarproyecto": {
                tm.templates().saveProject(r.joined(0), requireProject());
                out.println("Plantilla de proyecto '" + r.joined(0) + "' guardada.");
                break;
            }
            case "usar": {
                Task parent = r.has("en") ? taskInProject(Integer.parseInt(r.opt("en"))) : null;
                Task t = tm.addTaskFromTemplate(requireProject(), parent, r.positional.get(0), Dates.parse(r.opt("fecha")));
                out.println("Creada desde plantilla: " + t);
                break;
            }
            case "usarproyecto": {
                if (r.positional.size() < 2) throw new IllegalArgumentException("Use: plantilla usar-proyecto <plantilla> <nuevo nombre> [fecha=..]");
                current = tm.createProjectFromTemplate(r.positional.get(0), r.positional.get(1), Dates.parse(r.opt("fecha")));
                out.println("Creado " + current + " desde plantilla (seleccionado).");
                break;
            }
            default: throw new IllegalArgumentException("Subcomando de plantilla desconocido: " + a.positional.get(0));
        }
    }

    private void listTemplates() {
        out.println("Plantillas de tarea:     " + tm.templates().taskTemplateNames());
        out.println("Plantillas de proyecto:  " + tm.templates().projectTemplateNames());
    }

    // ------------------------------------------------------------------ utilidades
    private Project requireProject() {
        if (current == null) throw new IllegalStateException("No hay proyecto seleccionado. Use 'proyecto <nombre>' o 'usar'.");
        return current;
    }

    private Task taskInProject(int id) {
        return requireProject().find(id).orElseThrow(() -> new IllegalArgumentException("No existe la tarea #" + id + " en este proyecto."));
    }

    private static List<String> splitNames(String csv) {
        return Arrays.stream(csv.split("[,;]")).map(String::trim).filter(s -> !s.isEmpty()).collect(Collectors.toList());
    }

    // ------------------------------------------------------------------ análisis de la línea
    private record Token(String text, boolean quoted) {}

    private static List<Token> tokenize(String line) {
        List<Token> tokens = new ArrayList<>();
        StringBuilder cur = new StringBuilder();
        boolean inQuotes = false, quoted = false, started = false;
        for (char c : line.toCharArray()) {
            if (c == '"') { inQuotes = !inQuotes; quoted = true; started = true; }
            else if (Character.isWhitespace(c) && !inQuotes) {
                if (started) { tokens.add(new Token(cur.toString(), quoted)); cur.setLength(0); quoted = false; started = false; }
            } else { cur.append(c); started = true; }
        }
        if (started) tokens.add(new Token(cur.toString(), quoted));
        return tokens;
    }

    /** Argumentos separados en posicionales, opciones clave=valor y banderas sueltas. */
    private static class Args {
        final List<String> positional = new ArrayList<>();
        final Map<String, String> options = new LinkedHashMap<>();

        Args(List<Token> tokens) {
            for (Token t : tokens) {
                int eq = t.text.indexOf('=');
                if (!t.quoted && eq > 0) options.put(Texts.normalize(t.text.substring(0, eq)), t.text.substring(eq + 1));
                else positional.add(t.text);
            }
        }

        private Args() {}

        Args drop(int n) {
            Args r = new Args();
            r.positional.addAll(positional.subList(Math.min(n, positional.size()), positional.size()));
            r.options.putAll(options);
            return r;
        }

        boolean has(String key) { return options.containsKey(key); }
        String opt(String key) { return options.get(key); }

        /** Bandera sin valor ("vencidas", "desc", "plano"): se admite como palabra suelta. */
        boolean flag(String name) {
            return positional.stream().anyMatch(p -> Texts.normalize(p).equals(name)) || options.containsKey(name);
        }

        int id(int index) {
            if (positional.size() <= index) throw new IllegalArgumentException("Falta el id de la tarea.");
            try { return Integer.parseInt(positional.get(index).replace("#", "")); }
            catch (NumberFormatException e) { throw new IllegalArgumentException("Id inválido: " + positional.get(index)); }
        }

        String joined(int from) {
            if (positional.size() <= from) throw new IllegalArgumentException("Faltan argumentos. Escriba 'ayuda'.");
            return String.join(" ", positional.subList(from, positional.size()));
        }
    }
}
